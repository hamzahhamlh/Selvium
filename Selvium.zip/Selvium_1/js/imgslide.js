	// مصفوفه فيها أسما الصور الموجوده بمجلد
	let imgArray=['0.jpg','1.jpg','2.jpg','3.jpg','4.jpg'];
	
	// جلب المتغير
	let imgslide =document.getElementById ('imgslide')
    i = 0;
    imgslide.src =`../img/landing/img-slide/${imgArray[0]}`
	// داله تشتغل كل مده معينه
	setInterval (function (){
	
        if (i  >= imgArray.length) {
    
			i=0
        }
		// تغيير المسار من خلال تغيير السورس
		imgslide.src =`../img/landing/img-slide/${imgArray[i]}`
		// console.log(i);
		i++;
	}
        , 2500)
    