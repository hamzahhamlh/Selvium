const SAR = new Intl.NumberFormat('AR-US', {
  style: 'currency',
  currency: 'SAR',
  maximumFractionDigits: 0,
});
let container = document.getElementById("container");
let main_title =document.getElementById ("main-title") ;
function getRepos() {
  var myRequest = new XMLHttpRequest();

  myRequest.onreadystatechange = function () {
    
    
      if (this.readyState === 4 && this.status === 200) {
  
          var myJSObject = JSON.parse(this.responseText);
          var countMyJSObject = myJSObject.length;
          let myText = '';

      

          for (var i = 0; i < countMyJSObject; i++) {
            //   console.log(myJSObject[i]);
              let ID =  myJSObject[i].IdProduct;
              let name = myJSObject[i].product_name;
              let Category_name = myJSObject[i].name;
              let Price = myJSObject[i].Price;
              let Image = myJSObject[i].Image ; 
              let Description =myJSObject[i].Description;

              myText+= `
              <div class="box" >
              <img src="../img/imgbox/${Image}" alt="">
              <div class="content">
                  <h3>${SAR.format(Price)}</h3>
                  <p>${Description} </p>
             
              </div>
              <div class="info">
                  <a href="#">${name}  </a>
                
              </div>
              <div class="info">
                  <a href="#">${Category_name} </a>
                  <I  onclick="addToCart(${ID})"  class="fa-solid fa-cart-shopping fa-fw c-bule"> </I>
              </div>
                 
          </div>
              
              `;

    
          }   
          main_title.innerHTML = `كل المنتجات   (   ${countMyJSObject} )`;
          container.innerHTML = myText ; 
       
      }

  
  };


  myRequest.open('GET', './php/api_product.php', true);

  myRequest.send();
}
getRepos();


let title = document.title ;
// console.log(title)
 // داله عرض البيانات بحسب الفئه 
function show(id_Category){
  let tump = "";

  var myRequest = new XMLHttpRequest();

  myRequest.onreadystatechange = function () {
    

      if (this.readyState === 4 && this.status === 200) {
  
        let myJSObject = JSON.parse(this.responseText);
        let countMyJSObject = myJSObject.length;
        let myText = '';
        
      
            let count = 0 ;
          for (var i = 0; i < countMyJSObject; i++) {
        

            
            //   console.log(myJSObject[i]);
              let ID =  myJSObject[i].idProduct;
              let name = myJSObject[i].product_name;
              let Category_name = myJSObject[i].name;
              let Price = myJSObject[i].Price;
              let Image = myJSObject[i].Image ; 
              let Description =myJSObject[i].Description;
              if (id_Category == Category_name) {
              myText+= `
              <div class="box" >
              <img src="../img/imgbox/${Image}" alt="">
              <div class="content">
                  <h3>${SAR.format(Price)}</h3>
                  <p>${Description}</p>
              </div>
              <div class="info">
                  <a href="#">${name}</a>
             
              </div>
              <div class="info">
              <a href="#">${Category_name} </a>
              <I onclick="addToCart(${ID})"  class="fa-solid fa-cart-shopping fa-fw c-bule"> </I>
             
          </div>
          </div>
          
              
              `;
              count++;
            }
            else if (id_Category == 'كل المنتجات') {
                  getRepos();
            }
    
          }   
        
          container.innerHTML = myText  ; 
          main_title.innerHTML = `${id_Category} (   ${count} )`;
          document.title = `${title}- ${id_Category}`; 
          
      }

  
  };


  myRequest.open('GET', './php/api_product.php', true);

  myRequest.send();
    //   console.log(id_Category) ;

   
  
  
}

function select_category (){
   
  var myRequest = new XMLHttpRequest();

  myRequest.onreadystatechange = function () {
    
    
      if (this.readyState === 4 && this.status === 200) {
  
          var myJSObject = JSON.parse(this.responseText);
          var countMyJSObject = myJSObject.length;
          let myText = '';

      

          for (var i = 0; i < countMyJSObject; i++) {
            //   console.log(myJSObject[i]);
              let ID =  myJSObject[i].IdCategory;
              let name = myJSObject[i].name;
                
               myText+= `
                        <option value="${name}" >${name} </option> 
                        `;

          }   
          let select = document.getElementById("select");
          select.innerHTML += myText ; 
          
          select.addEventListener('change', (event) => {
            // console.log(event.target.value );
            show(event.target.value );
          
      
          
          });
      }

  
  };
  myRequest.open('GET', './php/api_category.php', true);
  myRequest.send();
}
select_category();