<?php

header("Access-Control-Allow-Origin: *"); 


function new_order(){
    include ("conn.php");
    $query ="SELECT  IdOrder   FROM  `$table_order` order by IdOrder";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    
     echo json_encode($data);
    
    header("Content-Type: JSON");
}


function select(){
    include ("conn.php");

    $table_stateorder = 'stateorder';
    $query ="SELECT
     d.IdDetail As IdDetail ,
     d.IdOrder  As IdOrder_detail,
     d.IdProduct,
     p.IdProduct As IdProduct_product,
     p.Name As Name_product,
     p.Price AS Price_product,
     d.Amount,
     d.Price As  Price, 
     o.IdOrder As IdOrder_order ,
     o.dateOrder As dateOrder,
     o.AddressOrder As AddressOrder,
     o.Payment As Payment,
     o.TotalPrice As TotalPrice,
     c.IdCustomer AS IdCustomer,
     c.Name As  Name_customer ,
     s.IdStateOrder,
     s.Name AS Name_stateorder,
     s.IdStateOrder As IdStateOrder
    FROM $table_detail d ,
        `$table_order` o ,
         $table_customer c,
         $table_stateorder s, 
         $table_product p
    WHERE d.IdOrder = o.IdOrder 
    AND c.IdCustomer = o.IdCustomer
    AND s.IdStateOrder = o.IdStateOrder
    AND p.IdProduct = d.IdProduct";

    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

    echo json_encode($data);
    // print_r($data) ;
    // header("Content-Type: JSON");
}






function select_order(){
    include ("conn.php");
    
    $table_stateorder = 'stateorder';
    $query ="SELECT
         o.IdOrder As IdOrder_order ,
         o.AddressOrder As AddressOrder,
         o.dateOrder As dateOrder,
         o.Payment As Payment,
         o.TotalPrice As TotalPrice,
         c.IdCustomer AS IdCustomer,
         c.Name As  Name_customer ,
         s.IdStateOrder As IdStateOrder,
         s.Name AS Name_stateorder
        FROM `$table_order` o ,
             $table_customer c,
             $table_stateorder s
        WHERE c.IdCustomer = o.IdCustomer
        AND s.IdStateOrder = o.IdStateOrder";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($data);
    // header("Content-Type: JSON");
}



function get_total ()
{
    include ("conn.php");
  
    $query ="SELECT
   d.IdDetail As IdDetail ,
   p.Price*d.Amount  As Price_p
  FROM $table_detail d ,
      `$table_order` o ,
       $table_customer c,
       $table_stateorder s, 
       $table_product p
  WHERE d.IdOrder = o.IdOrder 
  AND c.IdCustomer = o.IdCustomer
  AND s.IdStateOrder = o.IdStateOrder
  AND p.IdProduct = d.IdProduct
  order BY IdDetail";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    $i=0;
    while ($i  < count ( $data )  ){
  $IdDetail = $data[$i]['IdDetail'] ;
  $Price_p =  $data[$i]['Price_p'] ;
  // echo  $IdDetail ;
  // echo '<br>';
  // echo $Price_p ;
  $query_updeate ="UPDATE $table_detail d
  SET    d.Price =$Price_p
  WHERE d.IdDetail =".$IdDetail;
  $result = mysqli_query($connect,$query_updeate);
  $i++;
    }
}

function SumPrice()
{
    include ("conn.php");
    $query_order ="SELECT
      IdOrder, sum(Price) AS sum_Price
    FROM $table_detail d 
    GROUP By  IdOrder";
    $result = mysqli_query($connect,$query_order);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

    $i=0;
    // echo count ( $data ) ;
    while ($i  < count ( $data )  ){
    $IdOrder = $data[$i]['IdOrder'] ;
    $sum_Price =  $data[$i]['sum_Price'] ;

    $query_updeate ="UPDATE `$table_order` o
    SET    o.TotalPrice=$sum_Price
    WHERE o.IdOrder =".$IdOrder;
    $result = mysqli_query($connect,$query_updeate);
    $i++;
    }
 
    return 0 ;

}
function SET_TOTAL_Pris_0(){
    include ("conn.php");
    $query_order="SELECT o.IdOrder 
    FROM `$table_order` o
    WHERE NOT EXISTS (SELECT  d.IdOrder As  IdOrder  FROM $table_detail d WHERE o.IdOrder = d.IdOrder )";
    $result = mysqli_query($connect,$query_order);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode ($data);

    $i=0;
    while ($i  < count ( $data )  ){
    $IdOrder = $data[$i]['IdOrder'] ; 
  

    $query_updeate ="UPDATE `$table_order` o
     SET    o.TotalPrice = 0
    WHERE o.IdOrder =".$IdOrder;

    $result = mysqli_query($connect,$query_updeate);
    $i++;
    }
    return 0 ;
}

    

function update(){
        include "conn.php";
    
        if (isset ( $_POST['IdStateOrder'] ) && $_POST['IdOrder'] ){
            $IdStateOrder =    clear ($_POST['IdStateOrder'] );
            $IdOrder = clear($_POST['IdOrder']);
            $query ="UPDATE `$table_order` SET IdStateOrder ='".$IdStateOrder."' WHERE IdOrder =".$IdOrder;
    
            $results=mysqli_query($connect ,$query);
           if( $results ){
     
             print " تم تعديل   ".'<b class="c-main" >حاله  الطلب</b>'.' بنجاح  ';
            }
            else{
              print "لم يتم التعديل";
            }
        }
        else{
            print '<b class="c-red">يرجي  تحديد حاله !</b>' ;
        }
}
    





function sum_TotalPrice (){
        
        include ("conn.php");
        $IdCustomer = $_POST['IdCustomer'] ;
        $IdOrder = $_POST['IdOrder'] ;
        $query ="SELECT  sum(TotalPrice) AS sum_TotalPrice   FROM  `$table_order` 
        Where  IdCustomer=".$IdCustomer  ;
        $result = mysqli_query($connect,$query);
        $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
        
        echo json_encode($data);
        // header("Content-Type: JSON");
}


function insert_order (){
    include "conn.php";
       
    $IdOrder = clear($_POST['IdOrder']);
    $IdCustomer = clear($_POST['IdCustomer']);
    $IdStateOrder = 1;
    $AddressOrder = clear($_POST['AddressOrder']);
    date_default_timezone_set('Asia/Riyadh');
    // echo date('Y-m-d H:i:s');   
    // date_default_timezone_get() ;
    $dateOrder = date('Y-m-d H:i:s');
    $Payment = clear($_POST['Payment']);
    $TotalPrice = clear($_POST['TotalPrice']);

    $errors = array ();
    if (empty($IdOrder)):
        $errors []='<b class="c-main" >' .'   رقم الطلب   '.'</b>';
       
    endif;
    if (empty($IdCustomer)):
            $errors []='<b class="c-main" >' .'   معرف العميل   '.'</b>';
            
    endif;
    if (empty($IdStateOrder)):
        $errors []='<b class="c-main" >' .'   حاله الطلب  '.'</b>';
    endif;
    if (empty($dateOrder)):
        $errors []='<b class="c-main" >' .'    تاريخ الطلب '.'</b>';
    endif;
    if (empty($Payment)):
        $errors []='<b class="c-main" >' .'   طريقه الدفع'.'</b>';
    endif;
    if (empty($TotalPrice)):
        $errors []='<b class="c-main" >' .'    اجمالي السعر '.'</b>';
    endif;

    if (empty ( $errors)):
    $query="INSERT INTO `$table_order`
    (IdOrder ,IdCustomer,IdStateOrder,AddressOrder,dateOrder,Payment,TotalPrice)
    VALUES
    ('$IdOrder','$IdCustomer','$IdStateOrder','$AddressOrder','$dateOrder','$Payment','$TotalPrice') ";

       $results=mysqli_query($connect ,$query);
      if( $results ){

        echo "<b>تم أضافه الطلب بنجاح  </b>";
        return true ;
       }
         else{
         echo ' <b class="c-main" >' .' فشل في الاضافه '.'</b>';
         }
    else:
        echo ' يرجى ';
        foreach($errors as $err):
            echo ' أدخال '. $err .' و ';
        endforeach;
        echo 'من ثم جرب مرة أخرى';
    endif;

}
function delete_order (){
    include "conn.php";
    $id =    $_POST['ID'] ;

    $query="DELETE  FROM  `$table_order`  WHERE IdOrder =".$id;
    

       $results=mysqli_query($connect ,$query);
      if( $results ){

        print " تم   الغاء الطلب  " .'<b class="c-main" ></b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الحذف";
         echo $id;
       }
}
function insert_detail(){
    include "conn.php";
       
    $IdOrder = clear($_POST['IdOrder']);
    $IdProduct = clear($_POST['IdProduct']);
   
    $Amount = clear($_POST['Amount']);

 
    $Price = clear($_POST['Price']);
   

    $errors = array ();
    if (empty($IdOrder)):
        $errors []='<b class="c-main" >' .'   معرف  الطلب   '.'</b>';
       
    endif;
    if (empty($IdProduct)):
            $errors []='<b class="c-main" >' .'   معرف المنتج   '.'</b>';
            
    endif;
    if (empty($Amount)):
        $errors []='<b class="c-main" >' .'    الكمية  '.'</b>';
    endif;
    if (empty($Price)):
        $errors []='<b class="c-main" >' .'     السعر '.'</b>';
    endif;



    if (empty ( $errors)):
    $query="INSERT INTO `$table_detail`
    (IdOrder ,IdProduct,Amount,Price)
    VALUES
    ('$IdOrder','$IdProduct','$Amount','$Price') ";

       $results=mysqli_query($connect ,$query);
      if( $results ){

        print "<b>تم أضافه الطلب بنجاح  </b>";
        return true ;
       }
         else{
         print ' <b class="c-main" >' .' فشل في الاضافه '.'</b>';
         }
    else:
        echo ' يرجى ';
        foreach($errors as $err):
            echo ' أدخال '. $err .' و ';
        endforeach;
        echo 'من ثم جرب مرة أخرى';
    endif;
}
if ($_POST ['stats'] == 'select' )
{  
 
    select();
    return 0 ;
}
else if ($_POST['stats'] == 'select_order' )
{
    select_order();
    return 0 ;
}

else if ($_POST['stats'] == 'get_total' )
{  
    
    get_total();
    return 0 ;
}
else if ($_POST['stats'] == 'SumPrice' ){
    
    SumPrice ();

    return 0;
}
else if ($_POST['stats'] == 'SET_TOTAL_Pris_0' ){
    
    SET_TOTAL_Pris_0();
    return 0;
}
else if ($_POST['stats'] == 'update' ){
    update ();
    return 0;
}
else if ($_POST['stats'] == 'new_order' ){
    new_order ();
    return 0;
}
else if ($_POST['stats'] == 'insert' ){
    insert_order ();
    return 0;
}
else if ($_POST['stats'] == 'delete_order' ){
    delete_order ();
    return 0;
}
else if ($_POST['stats'] == 'insert_detail' ){
    insert_detail ();
    return 0;
}

else {
    select();
    return 0 ;
}

?>















