<?php

function select_product(){
  include ("test.php");
  $query ="SELECT  IdProduct ,p.name As product_name, Description , Image , Price ,Quantity , c.name 
           FROM $table_product p , $table_category c 
           WHERE p.IdCategory = c.IdCategory
           ORDER BY IdProduct";
  $result = mysqli_query($connect,$query);
  // $data =mysqli_fetch_all($result,MYSQLI_NUM);
  // $data =mysqli_fetch_all($result,MYSQLI_BOTH);
  $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
  echo json_encode($data);
  // echo json_decode($data);
  // header("Content-Type: JSON");
}
select_product();

// في دالة mysqli_fetch_all() في PHP، يمكن تحديد نوع المصفوفة التي يجب إنتاجها من الصف الحالي للبيانات12. هناك ثلاثة أنواع ممكنة12:

// MYSQLI_ASSOC: هذا المعامل يُنتج مصفوفة مرتبطة (associative array)، حيث تكون المفاتيح في المصفوفة هي أسماء الأعمدة من الاستعلام12.
// MYSQLI_NUM: هذا المعامل يُنتج مصفوفة رقمية (numeric array)، حيث تكون المفاتيح في المصفوفة هي الأرقام التسلسلية12.
// MYSQLI_BOTH: هذا المعامل يُنتج مصفوفة تحتوي على كلاً من الأسماء والأرقام التسلسلية كمفاتيح12.
// يرجى ملاحظة أن القيمة الافتراضية لهذا المعامل هي MYSQLI_NUM12.




