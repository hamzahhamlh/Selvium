<?php
session_start();
$Name_Customer = $_SESSION['client_name']; 
$Emile_Customer = $_SESSION['client_Email'] ;
$IdCustomer = $_SESSION['client_id'] ;
$Address = $_SESSION['client_Address'];
if (!empty ( $Name_Customer)){

  
  // echo '<input value="'.$IdCustomer.'"  name="IdCustomer"  id="IdCustomer" />';
  $data = array ();
  $data []=$Name_Customer ;
  $data []=$IdCustomer ;
  $data[]= $Address ;
  
  echo json_encode($data);
  return 0 ;

}
else {

  echo ' تسجيل الدخول   ' ;

  exit () ;

} ?>