<?php    session_start();
$name_sess = $_POST['username'] ;
$Password = $_POST['Password'] ;

$host="localhost";
$user="id21299170_nwrtalsyry";
$password="@Nj,pFtLAs5Y8&3r";
$dbname="id21299170_databeas";
$connect =mysqli_connect($host,$user,$password,$dbname);
$table_customer = 'customer';



$query ="SELECT  Name , Password , Email , IdCustomer ,Address FROM $table_customer 
where Email= \"$name_sess\" 
AND Password =".$Password;
$result = mysqli_query($connect,$query);
$data =mysqli_fetch_all($result,MYSQLI_ASSOC);


if ( $result &&  $data[0]['Email'] == $name_sess && $data[0]['Password'] == $Password) {
    echo ' تم الدخول جار تحويلك الى الصفحه الرئيسية ';
 
    // $_SESSION['client'] == $name_sess ;
    $_SESSION['client_name'] =$data[0]['Name'] ;
    $_SESSION['client_Email'] =$data[0]['Email'] ;
    $_SESSION['client_id'] =$data[0]['IdCustomer'] ;
    $_SESSION['client_Address'] =$data[0]['Address'] ;

    echo $_SESSION['client_name'];
    header('location: ../index.html');
    exit();
}

else {
    echo "يرجي التحقق من  صحه البيانات ";
    echo '<a href="../../login/index.php">المحاولة مرة أخرى </a>';
    
}
?>