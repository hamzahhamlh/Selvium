<?php


$host="localhost";
$user="id21299170_nwrtalsyry";
$password="@Nj,pFtLAs5Y8&3r";
$dbname="id21299170_databeas";
$connect =mysqli_connect($host,$user,$password,$dbname);
$table_category = 'category';
$table_product  = 'product';
$table_customer = 'customer';
$table_detail= 'detail';
$table_order = 'order';
$table_stateorder = 'stateorder';

function clear($input){
    $input = trim($input);
    $input = htmlspecialchars($input,ENT_QUOTES,'UTF-8');
    $input = strip_tags($input);
    return $input;
  }

// $query_order ="SELECT o.IdOrder AS IdOrder FROM `$table_order` o ";



function SET_TOTAL_Pris(){
include ("conn.php");
$query_order="SELECT o.IdOrder 
FROM `$table_order` o
WHERE NOT EXISTS (SELECT  d.IdOrder As  IdOrder  FROM $table_detail d WHERE o.IdOrder = d.IdOrder )";
$result = mysqli_query($connect,$query_order);
$data =mysqli_fetch_all($result,MYSQLI_ASSOC);
echo json_encode ($data);

$i=0;
    while ($i  < count ( $data )  ){
    $IdOrder = $data[$i]['IdOrder'] ; 
  

    $query_updeate ="UPDATE `$table_order` o
     SET    o.TotalPrice = 0
    WHERE o.IdOrder =".$IdOrder;

    $result = mysqli_query($connect,$query_updeate);
    $i++;
}
    return 0 ;
}

return 0 ;


