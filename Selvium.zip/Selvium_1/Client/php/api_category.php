<?php


    include ("test.php");

    $query ="SELECT IdCategory,name FROM $table_category";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($data);

    





