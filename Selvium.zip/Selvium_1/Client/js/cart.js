var cart = []; // this array will hold the products in the cart

function addToCart(product) {
    var productIndex = cart.findIndex(x => x == product); // find the product in the cart

    if (productIndex != -1) {
        // console.log(product + ' is already in the cart');
        alert(" تعذر الاضافه لان هذا المنتج موجود من قبل  ")
    } else {
        cart.push(product); // add the product to the cart
        localStorage.setItem('cart', JSON.stringify(cart)); // save the cart to localStorage
        // console.log(product + ' has been added to the cart');
        alert("  تمت أضافه المنتج الى السله بنجاح    ");
        get();
    }
}

//احذف من السله 
function removeFromCart(product) {
    var check_delete = prompt ("هل ترغب فعلا بازاله هذا المنتج من عربه التسوق   ",check_delete);
    if(check_delete == null){
        return false ;
    }

    var productIndex = cart.findIndex(x => x == product); // find the product in the cart

    if (productIndex != -1) {
        cart.splice(productIndex, 1); // remove the product from the cart
        localStorage.setItem('cart', JSON.stringify(cart)); // save the updated cart to localStorage
        // console.log(product + ' has been removed from the cart');
        // alert("  تمت حذف  المنتج من السله بنجاح    ");
        get();
        getRepos();
        
    } else {
        console.log(product + ' is not in the cart');
    }
}


// اعرض الي بداخل السله 

    function getRepos() {
    var savedCart = localStorage.getItem('cart'); // get the saved cart from localStorage
    console.log(savedCart)

        cart = JSON.parse(savedCart); // if a cart was saved, load it
        console.log(cart);
        const SAR = new Intl.NumberFormat('AR-US', {
            style: 'currency',
            currency: 'SAR',
            maximumFractionDigits: 0, 
          });
  
         
            var myRequest = new XMLHttpRequest();
          
            myRequest.onreadystatechange = function () {
              
              
                if (this.readyState === 4 && this.status === 200) {
            
                    var myJSObject = JSON.parse(this.responseText);
                    var countMyJSObject = myJSObject.length;
                    let myText = '';
          
                
                    for  ( let j = 0 ; j< cart.length ; j++ ) {
                        for (var i = 0; i < countMyJSObject; i++) {
                            
                            // console.log(myJSObject[i]);  
                            let ID =  myJSObject[i].IdProduct;
                            if ( ID == cart[j]){
                        let name = myJSObject[i].product_name;
                        let Category_name = myJSObject[i].name;
                        let Price = myJSObject[i].Price;
                        let Image = myJSObject[i].Image ; 
                        let Description =myJSObject[i].Description;

                        var productIndex = cart.findIndex(x => x == ID); // find the product in the cart
               
                     
                            // console.log(cart);
                            // console.log(ID);
                        myText+= `
                        <div class="box" >
                        <img src="../img/imgbox/${Image}" alt="">
                        <div class="content">
                            <h3>${SAR.format(Price)}</h3>
                            <p>${Description} </p>
                       
                        </div>
                        <div class="info">
                            <a href="#">${name}  </a>
                            </div>
                            <div class="info">
                            <a href="#">${Category_name} </a>
                            <I title="حذف من السله" onclick="removeFromCart(${ID})"  class="fa-regular fa-trash-can delete  fa-fw c-red"> </I>
                     </div>
                           
                    </div>
                        
                        `;
                        }
                    }
                        
                  
              
                    }   
                    let container = document.getElementById("container");
                    var main_title =document.getElementById ("main-title") ;
                    main_title.innerText = ` السلة  ${length_cart()} `;
                    container.innerHTML = myText ; 
                    
                }
          
            
            };
          
          
            myRequest.open('GET', './php/api_product.php', true);
          
            myRequest.send();
          }
          
          
          
          // console.log(title)
          // داله عرض البيانات بحسب الفئه 
          
          
          var savedCart = localStorage.getItem('cart');
          
          if (savedCart) {
        getRepos();
          }

// احسب كم في السلة 
function length_cart(){
    var savedCart = localStorage.getItem('cart'); // get the saved cart from localStorage
    if (savedCart) {
        cart = JSON.parse(savedCart); // if a cart was saved, load it
        
       
        return String ( `(${ cart.length })` ) ;
    }
    else {
        return String (  `( 0 )` );
    }
    
}
// console.log()
 // load the cart when the page loads

// document.title += length_cart () ;