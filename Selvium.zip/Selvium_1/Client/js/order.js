const SAR = new Intl.NumberFormat('AR-US', {
    style: 'currency',
    currency: 'SAR',
  });

  function formatDate(date) {
    let day = date.getDate();
    let month = date.getMonth() + 1; // يبدأ العد من 0
    let year = date.getFullYear();
    let hours = date.getHours();
    let minutes = date.getMinutes();
  
    // تحويل التنسيق إلى 12 ساعة
    let period = hours >= 12 ? 'م' : 'ص';
    hours = hours % 12;
    hours = hours ? hours : 12; // الساعة '0' يجب أن تكون '12'
  
    // إضافة الصفر قبل الأرقام الأحادية
    if (day < 10) day = '0' + day;
    if (month < 10) month = '0' + month;
    if (hours < 10) hours = '0' + hours;
    if (minutes < 10) minutes = '0' + minutes;
  
    return hours + ':' + minutes + '' + period +  ' ' + day + '-' + month + '-' + year; 
}

var datePro;
let table = new  DataTable('.table_order' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;

function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            table.destroy();
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';
            let mybox = '';
         
            let inp_IdCustomer = document.getElementById("IdCustomer");
            let IdCustomer_client = inp_IdCustomer.value ;
            // console.log(inp_IdCustomer.value);
            get_total();
            SumPrice();
            SET_TOTAL_Pris_0 ();
            // datePro.push(myJSObject);
            let  sum = 0;
            let temp =0  ; 
            let count = 0;
            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(datePro[i]);

                
                datePro.push(myJSObject[i]);
                // let IdOrder_detail=  datePro[i+1].IdOrder_detail;
                let IdOrder_order=  datePro[i+1].IdOrder_order;
                let IdCustomer=  datePro[i+1].IdCustomer;
                let Name_customer = datePro[i+1].Name_customer;
                if (IdCustomer_client  ==  IdCustomer ){
                    
                    let IdStateOrder = datePro[i+1].IdStateOrder;


                    let    StateOrder_btn_shep = IdStateOrder > 1  ? 'btn-shep': 'btn-shep-dis';
                    let    StateOrder_i = IdStateOrder > 1  ? '': 'fa-regular fa-trash-can    fa-fw';

                    let Name_stateorder = datePro[i+1].Name_stateorder;
                    
                    let dateOrder = datePro[i+1].dateOrder;
                    let date = new Date(dateOrder);
                    
                    let AddressOrder = datePro[i+1].AddressOrder;
                    
                    let Amount = datePro[i+1].Amount;
                    let Price = datePro[i+1].Price;
                    
                    let Payment = datePro[i+1].Payment;
                    let TotalPrice = datePro[i+1].TotalPrice;
                    temp +=parseInt( TotalPrice) ;
                    mybox+=`
                    <div class="box" >
              
                     <div class="info">
                        <b>   تاريخ الطلب  :  </b>
                        <b class="c">     ${ formatDate(date)   }	 <i class="fa-regular fa-calendar fa-fw f-w"></i>  </b>
                    </div>
                    <div class="info">
                    <b href="#"> حالة الطلب  </b>
                    <span for="table_Detail" onclick="delete_order(${IdOrder_order}, ${IdStateOrder}) " class="${StateOrder_btn_shep}" > ${Name_stateorder }
                    <i class="${StateOrder_i}"> </i>
                    
                    </span>
                </div>
                    <div class="content">
                    <h3>  <i class="fa-solid fa-money-bill-wave"></i><span> الاجمالي </span>  ${SAR.format (TotalPrice)} </h3>
                    <p> عنوان الطلب   :  
                    <b>${AddressOrder}</b></p>    
                      
                        </div>
                  
         
                        <div class="info" title="  انقر على الايقونه باليسار لعرض تفاصيل هذا الطلب ">
                        <span> طريقة الدفع : <b class="c-main"> ${Payment} </b> </span>
               
                        <a href="#table_Detail"  onclick="getDetail(${IdOrder_order})" > <i class="far fa-clipboard fa-fw f-w c-bule"></i></a>
                    </div>
                       
                </div>
                    ` ;
             /*       myText+= `<tr>
                    <td>${i+1}</td>
                    <td>${IdOrder_order}</td>
                    
               
                    <td>${Name_stateorder}</td>
                    
                    <td>${formatDate(date)}</td>
                    <td>${AddressOrder}</td>
                    
                    <td>${Payment}</td>
                    <td>${SAR.format (TotalPrice)}</td>
                    
                    
                    
                    <td ><a href="#table_Detail"><button  title="عرض تفاصيل الطلب ${IdOrder_order}" class="c-bule"  onclick="getDetail(${IdOrder_order})" > عرض    <i class="far fa-clipboard fa-fw f-w"></i></button></a></td>
                    <td><button title="الغاء   ${Name_stateorder}" class="c-red"   onclick="delete_order(${IdOrder_order}, ${IdStateOrder}) " >الغاء الطلب   <i class="fa-regular fa-trash-can delete f-w"></i></button></td>
                    </tr>`;*/
                    count++ ;
                }
                else {
                    
                    console.log ("x");
                }
            }
        sum = temp ;
            temp = 0;
            caption.innerHTML = ` لديك  ( ${count} )  اجمالي قيمه كل طلباتك  <b class="c-green f-15"> ${SAR.format (sum) } </b>`  ;
            let masg= document.getElementById('masg');
            masg.innerHTML = ` عدد الطلبات التي قمت بها  <u class= "c-main">${count}</u> اجمالي القيمه   الطلبات   <u class="c-green f-15">${SAR.format (sum) }</u>`  ;
            let tbody = document.getElementById("tbody");
            let container = document.getElementById("container");

            container.innerHTML = mybox ; 
            
         // tbody.innerHTML = myText ; 
        //    table = new  DataTable('.table_order' ,
        //     {   
        //         dom: 'Qlfrtip',
        //         language:{
        //             url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
        //         }
        //    }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_order.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select_order");
}
onload =  getRepos;



var date_order ;
var table_Detail = new  DataTable('.table_Detail' ,{

    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    },
  
}) ;



function getDetail(ID) {  
    let myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption_Detail =document.getElementById("caption_Detail");
        let count = 0 ;
        if (this.readyState === 4 && this.status === 200) {
            let myJSObject = JSON.parse(this.responseText);
            date_order=[];
            table_Detail.destroy();
            date_order.push(myJSObject) ;
            let countMyJSObject = myJSObject.length;
            let myDetail = '';
            
            
            // date_order.push(myJSObject);
            let  sum = 0;
            let temp =0  ; 
            let x=0 ;
            for (var i = 0; i < countMyJSObject; i++) {
                
                
                // console.log(date_order[i]);
                
                date_order.push(myJSObject[i]);
                
                let IdDetail=  date_order[i+1].IdDetail;
                let IdOrder_order=  date_order[i+1].IdOrder_order;
                
                let IdProduct_product=  date_order[i+1].IdProduct_product;
                let Name_product = date_order[i+1].Name_product;
                let Price_product = date_order[i+1].Price_product;
                
                
                let Amount = date_order[i+1].Amount;
                let Price = date_order[i+1].Price;
                
                temp =   (Amount * Price_product) ;
           
                let Name_stateorder = date_order[i+1].Name_stateorder;
                if (ID == IdOrder_order ) {
                    x = x+1 ;
                    count++ ;
                    sum +=temp ;
                    myDetail+= `<tr>
                    <td>${x}</td>
                    
                
                    
             
                    <td>${Name_product}</td>
                    <td>${SAR.format (Price_product)}</td>
                    

                    <td>${Amount}</td>
                    <td>${SAR.format (Price)    }</td>
                    
                  
                    </tr>`;
                }
            }   
         
                temp = 0 ;
            caption_Detail.innerHTML = `<b>عدد  الاصناف   (  ${count} ) </b>      اجمالي القيمه <b class="c-green f-15"> ${SAR.format (sum) } </b>`  ;
            let tbody_Detail = document.getElementById("tbody_Detail");
            tbody_Detail.innerHTML = myDetail ; 
           
            table_Detail = new  DataTable('.table_Detail' ,
            {   
                
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                },
             
           }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_order.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select");
}
// getDetail();





function get_total (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            // console.log ( this.responseText);    
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=get_total");
}

function SumPrice (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            console.log ( this.responseText);
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=SumPrice");
}


function SET_TOTAL_Pris_0 (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            console.log ( this.responseText);    
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=SET_TOTAL_Pris_0");
}

var IdOrder= document.getElementById("IdOrder") ;






let  IdCustomer = 0  ;
// بتجيب رقم العميل 
function get_data() {    
    var xhrhttp = new XMLHttpRequest();

    xhrhttp.onreadystatechange = function () {
    

        // console.log(this.status)
        // console.log (this.responseText)
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
 
            IdCustomer = myJSObject[1];
            Address = myJSObject[2];
           
        
            let inp_IdCustomer = document.getElementById("IdCustomer");
       
            
            inp_IdCustomer.value = IdCustomer ;
     
       
  
            

        }   
    
    };

    xhrhttp.open('GET', './php/Session_client.php', true);
    xhrhttp.send();
}
// console.log (get_data ());
get_data ()

function delete_order(IdOrder_order,IdStateOrder){
    if (IdStateOrder ===1 ){
 
        var check_delete = prompt ("هل ترغب فعلا بالغاء هذا الطلب سوف يتم حذف جميع التفاصيل المرتبطه بهذا الطلب ",check_delete);
        if(check_delete == null){
            return false ;
        }
   
        var myRequest = new XMLHttpRequest();
    
        let masg= document.getElementById('masg');
    
        myRequest.onreadystatechange = function () {
            
    
            console.log(IdOrder_order)
    
            if (this.readyState === 4 && this.status === 200) {
               
                getRepos() ;
                console.log ( this.responseText);
                masg.innerHTML = this.responseText ;
                
            }
        
        };
    
        myRequest.open('POST', "./php/api_order.php", true);
        myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
        myRequest.send("stats=delete_order&ID="+IdOrder_order);
    
    }
    else {

        console.log("لايمكن حذف الطلب لان حاله الطلب ليست قيد التنفيذ")
         
        let masg= document.getElementById('masg');
        masg.innerHTML =`<b class="c-main"> لايمكن حذف الطلب لان حاله الطلب ليست قيد التنفيذ </b>`;
    }
    
}




