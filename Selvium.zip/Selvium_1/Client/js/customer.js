var datePro;

// var  IdCustomer   = get_data ()  ;
// بتجيب رقم العميل 

function get_data() {    
    var xhrhttp = new XMLHttpRequest();

    xhrhttp.onreadystatechange = function () {
    

        // console.log(this.status)
        // console.log (this.responseText)
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
       

            //    datePro[0].IdCustomer = myJSObject[1]
                IdCustomer = myJSObject[1]

        }   
        
    };

    xhrhttp.open('GET', './php/Session_client.php', true);
    xhrhttp.send();
}
get_data()

function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
        
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';

           

            // datePro.push(myJSObject);

            for (var i = 0; i < countMyJSObject; i++) {
             
                datePro.push(myJSObject[i]);

                let ID=  datePro[i+1].IdCustomer;
                let name = datePro[i+1].Name;
    
                if (  IdCustomer == ID ) {

                    myText+= `
                    <button title="تعديل عميل  ${name}" class="c-green"  onclick="upDate_Customer(${i+1})" >تعديل  <i class="fa-solid fa-pen-to-square f-w"></i></button>
                    <button title="حذف عميل  ${name}" class="c-red"  name="ID" onclick="delete_Customer(${ID}) " >حذف حسابي   <i class="fa-regular fa-trash-can delete f-w"></i></button>
            `;
                }
              
 
             
            }   
          
            
            let bton =  document.getElementById("bton");
            bton.innerHTML  += myText ;
        }   
    
    };

    myRequest.open('POST', './php/api_customer.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select");
}

getRepos()


let masg= document.getElementById('masg');
function insert_customer (){
    var Name= document.getElementById('Name').value;
    var Password= document.getElementById('Password').value;
    var Email= document.getElementById('Email').value;
    var Mobile= document.getElementById('Mobile').value;
    var Age= document.getElementById('Age').value;
    var Address= document.getElementById('Address').value;

    console.log(Name);
    console.log(Password);
    console.log(Email);
    console.log(Mobile);
    console.log(Age);
    console.log(Address);
    var myRequest = new XMLHttpRequest();


    myRequest.onreadystatechange = function () {
        

        console.log(Name)

        if (this.readyState === 4 && this.status === 200) {
           
            // new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            // clear_input();  
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert&Name="+Name+"&Password="+Password+"&Email="+Email+"&Mobile="+Mobile+"&Age="+Age+"&Address="+Address);

}


function upDate_Customer( i ){
    let IdCustomer= document.getElementById('IdCustomer');
    var Name= document.getElementById('Name');
    var Password= document.getElementById('Password');
    var Email= document.getElementById('Email');
    var Mobile= document.getElementById('Mobile');
    var Age= document.getElementById('Age');
    var Address= document.getElementById('Address');
   
    
var btn_save = document.getElementById('btnsave') ;
    btn_save.style.display="inline";
   

    IdCustomer.value=datePro[i].IdCustomer;
    Name.value=datePro[i].Name;
    Password.value=datePro[i].Password;
    Email.value=datePro[i].Email;
    Mobile.value=datePro[i].Mobile;
    Age.value=datePro[i].Age;
    Address.value=datePro[i].Address;

    IdCustomer.value = datePro[i].IdCustomer ;
    Name.focus();
   
    // IdCustomer = datePro[i].IdCustomer;
    console.log (Name.value );
    // console.log ( IdCustomer );

    let masg= document.getElementById('masg');
    masg.innerHTML = `<b class="c-main">أضغط زر حفظ التغيرات بعد الانتهاء لتعديل ملفك الشخصي </b>`
  
}

var btn_save = document.getElementById('btnsave') ;

btn_save.style.display="none";



function set_update(){

    var IdCustomer= document.getElementById('IdCustomer').value;
    var Name= document.getElementById('Name').value;
    var Password= document.getElementById('Password').value;
    var Email= document.getElementById('Email').value;
    var Mobile= document.getElementById('Mobile').value;
    var Age= document.getElementById('Age').value;
    var Address= document.getElementById('Address').value;

    console.log(IdCustomer);
    console.log(Name);
    console.log(Password);
    console.log(Email);
    console.log(Mobile);
    console.log(Age);
    console.log(Address);

    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');
    myRequest.onreadystatechange = function () {
        

        console.log(Name)
        console.log(IdCustomer)

        if (this.readyState === 4 && this.status === 200) {
         
      
            console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
            let header = document.getElementById ("header");     
            header.innerHTML =''
            get ();

            var btn_save = document.getElementById('btnsave') ;
            btn_save.style.display="none";
          
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=update&IdCustomer="+IdCustomer+"&Name="+Name+"&Password="+Password+"&Email="+Email+"&Mobile="+Mobile+"&Age="+Age+"&Address="+Address);
}



function clear_input (){
    let Name= document.getElementById('Name');
    let Password= document.getElementById('Password');
    let Email= document.getElementById('Email');
    let Mobile= document.getElementById('Mobile');
    let Age= document.getElementById('Age');
    let Address= document.getElementById('Address');
     Name.value = " ";
     Password.value = "";
     Email.value ='';
     Mobile.value ='';
     Age.value ='';
     Address.value ='';
}



function delete_Customer (ID){
    var check_delete = prompt ("هل ترغب فعلا بحذف حسابك   سوف يتم حذف جميع البيانات والطلبات  التي قمت بها ",check_delete);
    if(check_delete == null){
        return false ;
    }

    var myRequest = new XMLHttpRequest();

    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        console.log(ID)

        if (this.readyState === 4 && this.status === 200) {
           
     
            console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=delete&ID="+ID);
}
