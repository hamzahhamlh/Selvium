document.body.innerHTML +=`    <div class="scroller"></div>

<button type="button" id="btn-scrool" src="...">
    <i class="fa-solid fa-angles-up mr-10"></i>
</button>`;
let header = document.getElementById ("header");




//------------------scroller------------
window.onscroll =scroller ;
function scroller(){
    let btn_scrool=document.getElementById('btn-scrool');
window.onscroll=function()
{
    if( scrollY >= 400)
    {
        btn_scrool.style.display='block';
    }
    else
    {
        btn_scrool.style.display='none';        
    }
}
        btn_scrool.onclick=function(){window.scrollTo({
            left:0,
            top:0,
            behavior:"smooth"
        })
}

    let el=document.querySelector('.scroller');
    let height=document.documentElement.scrollHeight-document.documentElement.clientHeight;
    
    // console.log(document.documentElement.scrollHeight);
    // console.log(document.documentElement.clientHeight);
    // console.log(height);
    
    window.addEventListener('scroll',()=>{
        let scrollTop =document.documentElement.scrollTop;
        // console.log(scrollTop);
        el.style.width=`${(scrollTop/height)*100}%`; 
    });
    
}


var  Name_Customer = "غير معروف " ;


function get() {    
    var xhrhttp = new XMLHttpRequest();

    xhrhttp.onreadystatechange = function () {
    

        // console.log(this.status)
        // console.log (this.responseText)
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            Name_Customer =myJSObject[0];
           
           
            // console.log(IdCustomer) ;
            let header = document.getElementById ("header");     
            header.innerHTML =` <div class="container">
            <a href="index.html" class="logo">سلفيوم</a>
            <ul class="main-nav">
                <li><a href="index.html">الرئيسيه</a>  </li>
                <li><a href="#"> الطلبات </a>
                    <div class="mega-menu">
            
                        <ul class="links">
                        <li>
                        <a href="order.html"><i class="fa-solid fa-list  fa-rotate-180 fa-fw"></i>طلباتي </a>
                        </li>
                      
                            <li>
                                <a href="new_order.html"><i class="fa-solid fa-list  fa-rotate-180 fa-fw"></i>طلب جديد </a>
                            </li>

                      
                        </ul>
            
                    </div>
                </li>
                <li>
                <li><a href="cart.html">السلة  ${length_cart()}</a>
          
                </li>
                <li><a href="./abot.html"> حول </a></li>
                <li><a href="../login/index.php">تسجيل الخروج</a>
          
                </li>
            
            </ul>
            <div>
            <a href="customer_update.html"><i class="far fa-user fa-fw"></i>${Name_Customer}</a>
            
            </div>
            </div>
            `;
        }
            
    
        
    
    };

    xhrhttp.open('GET', './php/Session_client.php', true);
    xhrhttp.send();
}


get () ;

