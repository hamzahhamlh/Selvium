const SAR = new Intl.NumberFormat('AR-US', {
    style: 'currency',
    currency: 'SAR',
  });
  function formatDate(date) {
    let day = date.getDate();
    let month = date.getMonth() + 1; // يبدأ العد من 0
    let year = date.getFullYear();
    let hours = date.getHours();
    let minutes = date.getMinutes();
  
    // إضافة الصفر قبل الأرقام الأحادية
    if (day < 10) day = '0' + day;
    if (month < 10) month = '0' + month;
    if (hours < 10) hours = '0' + hours;
    if (minutes < 10) minutes = '0' + minutes;
  
    return year + '-' + month + '-' + day ;
  }

var datePro;
let table = new  DataTable('.table_order' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;





var date_order ;
var table_Detail = new  DataTable('.table_Detail' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    },
  
}) ;









var IdOrder= document.getElementById("IdOrder") ;

function new_order(){
    var xhrhttp = new XMLHttpRequest();
    xhrhttp.onreadystatechange = function () {
    

        // console.log(this.status)
        // console.log (this.responseText)
       

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            var countMyJSObject = myJSObject.length;
        
            
            console.log ( this.responseText);
            console.log ( countMyJSObject);
            if (countMyJSObject == 0 ){
                IdOrder.value =  1  ;
            }
            for (var i = 0; i < countMyJSObject; i++) {
                
                val =   myJSObject[i].IdOrder;
                console.log ( myJSObject[i].IdOrder ); 

               
              
                IdOrder.value = parseInt(myJSObject[i].IdOrder  ) + 1  ;
                
            }

        }   
    
    };

    xhrhttp.open('POST', './php/api_order.php', true);
    xhrhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhrhttp.send("stats=new_order");
}
// بتجيب رقم اخر طلب في جدول الطلبات 



let  IdCustomer = 0  ;
var Addres ;

// بتجيب رقم العميل 
function get_data() { 
    var xhrhttp = new XMLHttpRequest();

    xhrhttp.onreadystatechange = function () {
    

        
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
 
            IdCustomer = myJSObject[1];
             Addres = myJSObject[2];
             new_order(); 
             let  inp_Address = document.getElementById("AddressOrder");
             inp_Address.value = Addres.toString( ) ;
            
            let inp_IdCustomer = document.getElementById("IdCustomer");
            inp_IdCustomer.value = IdCustomer ;
            
            

            
         
        }   
     
   
    };

    xhrhttp.open('GET', './php/Session_client.php', true);
    xhrhttp.send();
}

onload =  get_data ;

// مصفوفه تجيب لك بيانات المنتجات 
var dateProduct ;

function getProduct() {
    var myRequest = new XMLHttpRequest();

    myRequest.onreadystatechange = function () {
      
 
        if (this.readyState === 4 && this.status === 200) {
            let caption =document.getElementById("caption_product");
            var myJSObject = JSON.parse(this.responseText);
            
            var countMyJSObject = myJSObject.length;
            let myText = '';

            dateProduct=[];
         
            dateProduct.push(myJSObject);
            for (var i = 0; i < countMyJSObject; i++) {
                dateProduct.push(myJSObject[i]);
       
                let ID =  dateProduct[i+1].IdProduct;
                let name = dateProduct[i+1].product_name;
                let Category_name = myJSObject[i].name;
                let Image = myJSObject[i].Image;
                let Price = dateProduct[i+1].Price;
                let tumPrice = SAR.format(Price)
                
                caption.innerHTML = `كل المنتجات ( ${countMyJSObject} )`  ;

                 myText+= `<tr onclick="select_product(${i+1},${i},${ID})" >
                    <td>${i+1}</td>
                    <td>${name}</td>
                    <td>${Category_name}</td>
                    <td><img src="../img/imgbox/${Image}"></td>
                
                    <td>${tumPrice}</td>
                    <td tabindex="${i}"><button title="اختيار  " class="c-bule "  onclick="select_product(${i+1},${i},${ID})" >اختيار  <i class="fa-solid fa-check  f-w"></i></button></td>
                     </tr>`;

            }   
            let tbody = document.getElementById("tbody_product");
            tbody.innerHTML = myText ; 
             table_product = new  DataTable('.table_product' ,{
                    dom: 'Qlfrtip',
                    language:{
                            url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                        }
                       }) ;
   
        }
 

    
    };
  

    myRequest.open('GET', './php/api_product.php', true);
    myRequest.send();
}
getProduct();





var deteDetail = [] ;
var newDetail ;
// داله تسوي تفاصيل الطلب 
function select_product(i , x ,ID ){
    let form = document.getElementById('forms');
 
    
    console.log (deteDetail.length )    
    x= deteDetail.length ;  
   
    for ( let j = 0 ; j<deteDetail.length ; j++ ){
  
        if (  ID == deteDetail[j].IdProduct){
            let masg = document.getElementById('masg');
            window.scrollTo({
                left:0,
                top:100,
                behavior:"smooth"
            })
            masg.innerHTML = `<b class="c-red">لقد اخترت هذا المنتج من قبل يرجى اختيار منتج اخر </b>`
            close_product()
            return 0 ;
        }

        
    }
  

    



    form.innerHTML +=`
    <tr id="row_${x}" >
   
    <td>
    <input class="w-50p d-none" type="number"  value="${IdOrder.value}"   id="IdOrder_det${x}">
    <input class="w-50p d-none" type="text" value="${dateProduct[i].IdProduct}" id="IdProduct${x}">
    <span class="f-grow no-back" type="text" value="" id="product_name${x}">${dateProduct[i].product_name}</span>
    </td>
    <td>
    <span class="f-grow txt-c ">   
    
    <span class="f-grow txt-c ">  ${ SAR.format(dateProduct[i].Price)} </span>
    </span>
    <input  type="text" class="d-none" id="Price${x}" value="${dateProduct[i].Price}" >
    </td>
    <td>
    <button onclick="minus(${x})" class="p-3" id="minus${x}"> <i class="fa-sharp fa-solid fa-minus c-main"></i></button>
    </td>
    <td>
    <input type="text" class="d-none" readonly class="w-50p no-back"  value="" id="Amount${x}" >
    <span  class="w-50p txt-c"   id="spanAmount${x}" ></span>
    </td>
    <td>
    <button  onclick="plus(${x})" class="p-3" id="plus${x}"> <i class="fa-sharp fa-solid fa-plus c-main"></i></button>
    </td>

    <td>
    <input type="text"  class="d-none" id="Price_det${x}" value="${dateProduct[i].Price}" >
    <span id="span_Price${x}" class="c-green txt-c f-grow span"> </span>
    </td>
    
    </tr>`;
  
    
     product_name=document.getElementById(`product_name${x}`)
    
     
     Price=document.getElementById(`Price${x}`)
     console.log(Price)
     
  
     IdOrder_det=document.getElementById(`IdOrder_det${x}`)
     console.log(IdOrder_det)

     IdProduct=document.getElementById(`IdProduct${x}`)
     console.log(IdProduct)
     Amount = document.getElementById(`Amount${x}`)

  

    

     Price_det=document.getElementById(`Price_det${x}`)
     console.log(Price_det)
    console.log(dateProduct[i])

    IdProduct.value=dateProduct[i].IdProduct;
    product_name.value=dateProduct[i].product_name;
    Price.value= dateProduct[i].Price;


    IdOrder_det.value= IdOrder.value ;
   
    Price_det.value= (Amount.value *  Price.value) ;





     newDetail=
    {
        x:x,
        IdProduct: dateProduct[i].IdProduct ,
        IdOrder_det:IdOrder_det.value, 
        Amount:Amount.value ,
        Price_det:Price_det.value
    }
    
    deteDetail.push (newDetail)
    let masg = document.getElementById('masg');
    masg.innerHTML = `<b class="c-bule">  تم اختيار (${deteDetail.length}) </b>`
    
    
    console.log(deteDetail)
    plus(x) ;   

   

let  pluss=document.getElementById(`plus${x}`)

pluss.focus();
ste_value(x)
close_product()
return 0 ;

}
function close_product(){
    let  table_product_wrapper =  document.getElementById('table_product_wrapper');
    table_product_wrapper.style.transform ="scale(0)";

   console.log("close_product")
   }

function fn_sum_det(x) {
 Amount=document.getElementById(`Amount${x}`)
 Amount.value = deteDetail[x].Amount ; 
 Price=document.getElementById(`Price${x}`)
 Price_det=document.getElementById(`Price_det${x}`)
 Price_det.value= (Amount.value *  Price.value);  
 deteDetail[x].Price_det = Price_det.value  ;
 deteDetail[x].Amount = Amount.value  ;
 console.log(deteDetail)
 fnu_span_Price(x);
 ste_value(x)
 return 0 ;
}

function minus(x){
     Amount=document.getElementById(`Amount${x}`)
    Amount.value -=parseInt ( 1 ) ;
    if (Amount.value <=parseInt ( 0)  ||  Amount.value ===  NaN ){
        let masg = document.getElementById('masg');
        masg.innerHTML = `<b class="c-red">عذرا الحد الادنى للكمية هي 1 على الاقل</b>`
        Amount.value = 1 
        return 0
    }
    deteDetail[x].Amount--;
    fn_sum_det(x)
    TotalPrice_all ();
    return 0 ;
}

function ste_value(x){

    AmountPrev =document.getElementById(`Amount${x}`)
    spanAmount =document.getElementById(`spanAmount${x}`)
    
    AmountPrev.value = parseInt (  deteDetail[x].Amount ); 
    spanAmount.innerHTML  = deteDetail[x].Amount ; 
}
function plus(x){
    ste_value(x)
    Amount=document.getElementById(`Amount${x}`)
    // Amount.value++;
    deteDetail[x].Amount++ ;
    Amount.value = deteDetail[x].Amount ;
    fn_sum_det(x)

    let masg = document.getElementById('masg');
    masg.innerHTML = `<b class="c-bule">  تم اختيار (${deteDetail.length}) </b>`;
    TotalPrice_all ();
    return 0 ;
}

function fnu_span_Price (x){
     Price=document.getElementById(`Price${x}`)
     Amount=document.getElementById(`Amount${x}`)

    span_Price=document.getElementById(`span_Price${x}`)

    span_Price.innerHTML =  SAR.format (  parseInt ( deteDetail[x].Price_det= (deteDetail[x].Amount *  Price.value) ) );

TotalPrice_all ();
return 0 ;
}


function TotalPrice_all(){
    var TotalPrice_ord = document.getElementById('TotalPrice');
    var Total = document.getElementById('Total');
    let sum = 0;
  
    for ( let j = 0 ; j<deteDetail.length ; j++ ){
       sum = sum +  parseFloat (deteDetail[j].Price_det ) 
    }
    TotalPrice_ord.innerHTML   =  SAR.format(sum)  ;
    Total.value = sum ;
    return 0 ;
}

function insert_order(){
    if ( deteDetail.length == 0 ){
        let masg= document.getElementById('masg');
        masg.innerHTML= `<b class="c-main">قبل تاكيد الطلب يجب التاكد انك اخترت منتج واحد على الاقل<b>`

        return 0 ; 
    }
    //1
    let IdOrder = deteDetail[0].IdOrder_det ;
    console.log(IdOrder);

    //2
    console.log ( IdCustomer) 

    //3
    let AddressOrder = document.getElementById("AddressOrder");
    let Address = AddressOrder.value;
    console.log ( Address) 
    
    //4
    let Payment = document.getElementById("Payment");
    let Pay = Payment.value
    console.log(Pay)
    
    //5
    let TotalPrice = document.getElementById("Total");
    let Total = TotalPrice.value;
    console.log(Total)

  


    var myRequest = new XMLHttpRequest();
    
    myRequest.onreadystatechange = function () {
        let masg= document.getElementById('masg');
        
        masg.innerHTML = this.responseText ;
      

        if (this.readyState === 4 && this.status === 200) {
            alert("   تم أضافه الطلب بنجاح   ")
            if (this.response == '<b>تم أضافه الطلب بنجاح  </b>')
            {

                // console.log ( this.responseText);
                masg.innerHTML = this.responseText ;

                insert_Detail (IdOrder)
            }
            else {
                alert("لم يتم أضافه الطلب حصلت مشكلة")
                return 0 ;
            }
            deteDetail = [];
            form.innerHTML ='';
            form.innerHTML = this.responseText ;
                }
    
    };

    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert&IdOrder="+IdOrder+"&IdCustomer="+IdCustomer+"&AddressOrder="+Address+"&Payment="+Pay+"&TotalPrice="+Total);

}

function insert_Detail (IdOrder){

console.log (IdOrder)
console.log (deteDetail.length)


for ( i=0 ; i< deteDetail.length ; i++ ) {

    console.log(deteDetail[i])
    let IdProduct = deteDetail[i].IdProduct ;
    let IdOrder = deteDetail[i].IdOrder_det ;
    let Amount = deteDetail[i].Amount ;
    let Price = deteDetail[i].Price_det ;

    console.log(IdProduct) 
    console.log(IdOrder) 
    console.log(Amount) 
    console.log(Price) 

     var myRequest = new XMLHttpRequest();
     
     myRequest.onreadystatechange = function () {
             
         if (this.readyState === 4 && this.status === 200) {
             
             let masg= document.getElementById('masg');
             
            // console.log ( this.responseText);
            // masg.innerHTML = this.responseText ;
            
        }
    
    };

    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert_detail&IdOrder="+IdOrder+"&IdProduct="+IdProduct+"&Amount="+Amount+"&Price="+Price);



}
   
}