<?php
// header("Access-Control-Allow-Origin: *"); 

function select(){
    include ("conn.php");
$query ="SELECT  IdAdmin ,Name , Password , Email , Mobile ,IsAdmin 
         FROM $table_admin ";
$result = mysqli_query($connect,$query);
$data =mysqli_fetch_all($result,MYSQLI_ASSOC);

echo json_encode($data);

// header("Content-Type: JSON");
}

function insert(){
    include ("conn.php");
   
    $Name = clear($_POST['Name']);
    $Password = clear($_POST['Password']);
    $Email = clear($_POST['Email']);
    $Mobile = clear($_POST['Mobile']);
    $IsAdmin = clear($_POST['IsAdmin']);

    $errors = array ();
    if (empty($Name)):
        $errors []='<b class="c-main" >' .'   أسم المستخدم '.'</b>';
       
    endif;
    if (empty($Password)):
            $errors []='<b class="c-main" >' .'   كلمه سر قويه'.'</b>';
            
    endif;
    if (empty($Email)):
        $errors []='<b class="c-main" >' .'   ألايميل '.'</b>';
    endif;
    if (empty($Mobile)):
        $errors []='<b class="c-main" >' .'   رقم الهاتف'.'</b>';
    endif;
    if (empty($IsAdmin)):
        $errors []='<b class="c-main" >' .'   الصلاحية'.'</b>';
    endif;

    if (empty ( $errors)):
    $query="INSERT INTO $table_admin
    (Name ,Password,Email,Mobile,IsAdmin)
    VALUES('$Name','$Password','$Email','$Mobile',$IsAdmin) ";

       $results=mysqli_query($connect ,$query);
      if( $results ){
        print " تم أضافه مستخدم بنجاح  ";
       }
         else{
         print ' <b class="c-main" >' .'فشل في الاضافه حاول التاكد من استخدام ايميل ورقم هاتف مختلف'.'</b>';
         }
    else:
        echo ' يرجى ';
        foreach($errors as $err):
            echo ' أدخال '. $err .' و ';
        endforeach;
        echo 'من ثم جرب مرة أخرى';
    endif;

    
}

function update (){
    include ("conn.php");
    $IdAdmin =clear($_POST['IdAdmin']);
    $Name = clear($_POST['Name']);
    $Password = clear($_POST['Password']);
    $Email = clear($_POST['Email']);
    $Mobile = clear($_POST['Mobile']);
    $IsAdmin = clear($_POST['IsAdmin']);
    $errors = array ();
    if (empty($Name)):
        $errors []='<b class="c-main" >' .'   أسم المستخدم '.'</b>';
       
    endif;
    if (empty($Password) ):
            $errors []='<b class="c-main" >' .'   كلمه سر قويه'.'</b>';
            
    endif;
    if (empty($Email)):
        $errors []='<b class="c-main" >' .'   ألايميل '.'</b>';
    endif;
    if (empty($Mobile)):
        $errors []='<b class="c-main" >' .'   رقم الهاتف'.'</b>';
    endif;
    if (empty($IsAdmin)):
        $errors []='<b class="c-main" >' .'   الصلاحية'.'</b>';
    endif;



    if (empty ( $errors)):
        // echo strtolower(end(explode ('@',$Email))) ;
        // echo "<br>";
        // $Em = $Email."@gamil.com"; 
        // echo $Em;
        $query="UPDATE  $table_admin
        SET
        Name='".$Name."' ,Password = '".$Password."',Email ='".$Email."',Mobile = '".$Mobile."',IsAdmin = '".$IsAdmin."'
        WhERE IdAdmin=".$IdAdmin;
    
           $results=mysqli_query($connect ,$query);
          if( $results ){

            print " تم تعديل المستخدم بنجاح  ";

            echo '<b class="c-green">'. $Name .'</b>' ;
           }
             else{
             print ' <b class="c-main" >' .'فشل في التعديل حاول التاكد من استخدام ايميل ورقم هاتف مختلف'.'</b>';
             }
        else:
            echo ' يرجى ';
            foreach($errors as $err):
                echo ' أدخال '. $err .' و ';        
            endforeach;
            echo 'من ثم جرب مرة أخرى';
        endif;
    


}


function delete(){
    include "conn.php";
    $id =    $_POST['ID'] ;

    $query="DELETE  FROM $table_admin  WHERE IdAdmin =".$id;
    

       $results=mysqli_query($connect ,$query);
      if( $results ){

        print " تم حذف  المستخدم " .'<b class="c-main" >'.  $id . '</b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الحذف";
         echo $id;
       }

}

if ($_POST ['stats'] == 'select' )
{  
    select();
    return 0 ;
}
else if ($_POST['stats'] == 'insert' )
{
    insert();
    return 0 ;
}
else if ($_POST['stats'] == 'delete' )
{
    delete();
    return 0 ;
}
else if ($_POST['stats'] == 'update' ){
    update ();
    return 0;
}

else {
    select();
    return 0 ;
}
?>

