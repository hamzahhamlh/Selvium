<?php 
 $host="localhost";
 $user="id21299170_nwrtalsyry";
 $password="@Nj,pFtLAs5Y8&3r";
 $dbname="id21299170_databeas";
 $connect =mysqli_connect($host,$user,$password,$dbname);
 $table_product  = 'product';
 $table_category = 'category';
 $table_customer = 'customer';
 $table_admin = 'admin';
 $table_detail= 'detail';
 $table_order = 'order';
 $table_stateorder = 'stateorder';


?>