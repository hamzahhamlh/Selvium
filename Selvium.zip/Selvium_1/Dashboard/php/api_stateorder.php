<?php
// header("Access-Control-Allow-Origin: *"); 

function select(){
    include ("conn.php");
    $query ="SELECT IdStateOrder,name FROM  $table_stateorder ";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($data);
    // header("Content-Type: JSON");
    }

function insert(){
    include "conn.php";

    if (isset( $_POST['name'])  && !empty($_POST['name'])) {
    $name = clear($_POST['name']);
    $query="INSERT INTO  $table_stateorder  (name)   VALUES ('$name')  ";
       $results=mysqli_query($connect ,$query);
      if( $results ){
        print " تم أضافه  الحالة " .'<b class="c-main" >'.  $name . '</b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الاضافه";
       }
}
else{
    print '<b class="c-red">يرجي أدخال اسم !</b>' ;
}
         
}

 function update(){
    include "conn.php";

    if (isset ( $_POST['name'] ) && $_POST['IdStateOrder'] ){
        $name =    clear ($_POST['name'] );
        $IdStateOrder = clear($_POST['IdStateOrder']);
        $query ="UPDATE  $table_stateorder  SET Name ='".$name."' WHERE IdStateOrder =".$IdStateOrder;

        $results=mysqli_query($connect ,$query);
       if( $results ){
 
         print " تم تعديل الحالة الى  ".'<b class="c-main" >'.  $name . '</b>'.' بنجاح  ';
        }
        else{
          print "لم يتم التعديل";
        }
    }
    else{
        print '<b class="c-red">يرجي أدخال اسم !</b>' ;
    }
 }
function delete(){
    include "conn.php";
    $id =    $_POST['ID'] ;
    $query="DELETE  FROM  $table_stateorder   WHERE IdStateOrder =".$id;
       $results=mysqli_query($connect ,$query);
      if( $results ){

        print " تم حذف   " .'<b class="c-main" >  الحالة   </b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الحذف";

       }

}



if ($_POST ['stats'] == 'select' )
{  
    select();
    return 0 ;
}
else if ($_POST['stats'] == 'insert' )
{
    insert();
    return 0 ;
}
else if ($_POST['stats'] == 'delete' )
{
    delete();
    return 0 ;
}
else if ($_POST['stats'] == 'update' ){
    update ();
    return 0;
}

else {
    select();
    return 0 ;
}


?>



