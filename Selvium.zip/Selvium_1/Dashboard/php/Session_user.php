<?php
session_start();
$userName  = $_SESSION['name']; 
$userEmile = $_SESSION['Email'] ;
if (!empty ( $userName)){

  echo  $userName ;
  echo $userEmile ;
  return 0 ;

}
else {
  echo ' تسجيل الدخول   ' ;

  exit () ;

} ?>