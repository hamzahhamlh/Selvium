<?php
 $host="localhost";
 $user="id21299170_nwrtalsyry";
 $password="@Nj,pFtLAs5Y8&3r";
 $dbname="id21299170_databeas";
 $connect =mysqli_connect($host,$user,$password,$dbname);


    $query ="SELECT * from  orders";

    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

    echo json_encode($data);

    header("Content-Type: JSON");