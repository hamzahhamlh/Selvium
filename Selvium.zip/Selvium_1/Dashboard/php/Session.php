<?php
session_start();
if (isset ($_POST['username'] ) &&  !empty($_POST['username']) && !empty ($_POST['Password']) ){


$name_sess = $_POST['username'] ;
$Password = $_POST['Password'] ;


$host="localhost";
$user="id21299170_nwrtalsyry";
$password="@Nj,pFtLAs5Y8&3r";
$dbname="id21299170_databeas";
$connect =mysqli_connect($host,$user,$password,$dbname);

$table_admin = 'admin';


$query ="SELECT Name , Password , Email , IsAdmin FROM $table_admin 
where Email= \"$name_sess\" 
AND Password =".$Password;
$result = mysqli_query($connect,$query);
$data =mysqli_fetch_all($result,MYSQLI_ASSOC);


if ( $result  && ($data[0]['Email'] ==$name_sess && $data[0]['Password']==$Password) ) {
    
    // echo ' تم الدخول جار تحويلك الى الصفحه الرئيسية ';
 
    // $_SESSION['user'] == $name_sess ;
    $_SESSION['name'] =$data[0]['Name'] ;
    $_SESSION['IsAdmin'] =$data[0]['IsAdmin'] ;
    $_SESSION['Email'] =$data[0]['Email'] ;
    
    header('location: ../index.html');
    exit();
}

else {

    
    echo "<script>alert('يرجى التحقق من صحه البيانات' ) </script>";
    echo '<a href=" ../../login/index.html">المحاولة مرة أخرى</a>';

}
}

else {
    echo "<script>alert('من فضلك قم بادخال البريد الالكتروني وكلمه المرور') </script>";
}
?>