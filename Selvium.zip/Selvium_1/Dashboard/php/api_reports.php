<?php 

$report = array ();

function select_count_porduct(){
    include "conn.php";
    $query ="SELECT COUNT(*) As select_count_porduct FROM  $table_product ";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    return '<b class="c-main" >' .' عدد المنتجات '.$data[0]['select_count_porduct']; 

    }
    function select_SUM_Price_porduct(){
        include ("test.php");
        $query ="SELECT SUM(Price) As select_SUM_Price_porduct FROM  $table_product ";
        $result = mysqli_query($connect,$query);
        $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
        return '<span class="c-bule" >' .'  أجمالي قيمة المنتجات  '.$data[0]['select_SUM_Price_porduct'].'</span></b>'; 
    
        }
function select_count_category(){
    include ("test.php");
    $query ="SELECT COUNT(*) As select_count_category FROM  $table_category ";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
   
    
    return '<b class="c-main" >' .' عدد الاقسام '.$data[0]['select_count_category'].'</b>'; 
  
    }
    function select_count_customer(){
        include ("test.php");
        $query ="SELECT COUNT(*) As select_count_customer FROM  $table_customer ";
        $result = mysqli_query($connect,$query);
        $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
        
        return '<b class="c-main" >' .' عدد العملاء '.$data[0]['select_count_customer'].'</b>' ; 
        }
    function select_count_admin(){
        include ("test.php");
        $query ="SELECT COUNT(*) As select_count_admin FROM  $table_admin ";
        $result = mysqli_query($connect,$query);
        $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

        
         return '<b class="c-main" >' .' عدد المستخدمين '.$data[0]['select_count_admin'].'</b>' ;
        }

        function select_count_stateorder(){
            include ("test.php");
            $query ="SELECT COUNT(*) As select_count_stateorder FROM  $table_stateorder ";
            $result = mysqli_query($connect,$query);
            $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    
            
             return '<b class="c-main" >' .' عدد حالات الطلب  '.$data[0]['select_count_stateorder'].'</b>' ;
            }
        function select_count_order(){
            include ("test.php");
            $query ="SELECT COUNT(*) As select_count_order FROM  `$table_order` ";
            $result = mysqli_query($connect,$query);
            $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    
            
             return '<b class="c-main" >' .' عدد  الطلبات  '.$data[0]['select_count_order'] ;
            }

        function select_SUM_Price_order(){
            include ("test.php");
            $query ="SELECT SUM(TotalPrice) As select_SUM_Price_order FROM  `$table_order` ";
            $result = mysqli_query($connect,$query);
            $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
            return '<span class="c-bule" >' .'  أجمالي قيمة طلبات العملاء  '.$data[0]['select_SUM_Price_order'].'</span></b>'; 
        
            }
        function select_count_detail(){
            include ("test.php");
            $query ="SELECT COUNT(*) As select_count_detail FROM  `$table_detail` ";
            $result = mysqli_query($connect,$query);
            $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    
            
             return '<b class="c-main" >' .' عدد  تفاصيل الطلبات   '.$data[0]['select_count_detail']  ;
            }
        function select_SUM_Price_detail(){
            include ("test.php");   
            $query ="SELECT SUM(Price) As select_SUM_Price_detail FROM  `$table_detail` ";
            $result = mysqli_query($connect,$query);
            $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
            return '<span class="c-bule" >' .  '  أجمالي قيمة  تفاصيل الطلبات  '.$data[0]['select_SUM_Price_detail'].'</span></b>'; 
        
            }


            date_default_timezone_set('Asia/Riyadh');
        
        $report [] = '<b class="c-"> أخر تحديث للبيانات تم الساعه '.'<span class="c-bule" >' . date(' h:i:s A ') .'</span>'.' بتاريخ  ' .'<span  class="c-bule">'.date('YMD Y/m/d  '). '</span>  بتوقيت الرياض </b>';
        $report []=select_count_porduct() . select_SUM_Price_porduct();
        $report []= select_count_order() . select_SUM_Price_order();
        $report []= select_count_detail().select_SUM_Price_detail();
        $report []= select_count_category();
        $report []= select_count_customer();
        $report []= select_count_admin();
        $report []= select_count_stateorder();
        
        

 

    foreach($report as $err):
        echo  $err .' <br> ';        
    endforeach;
?>