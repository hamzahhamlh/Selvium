<?php
session_start();

// تدمير متغيرات الجلسة المحددة

unset($_SESSION['user']);
unset($_SESSION['name']);
unset($_SESSION['IsAdmin']);
unset($_SESSION['Email']);
header('location: ../../login/index.html');
?>