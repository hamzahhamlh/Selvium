<?php
       if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                return   select();
       }
     
?>
<?php


    if ($_POST ['stats'] == 'select' )
{  
    select();
    return 0 ;
}
else if ($_POST['stats'] == 'insert' )
{
    insert_product();
    return 0 ;
}
else if ($_POST['stats'] == 'delete' )
{
    delete_product();
    return 0 ;
}
else if ($_POST['stats'] == 'update' ){
    update_product ();
    return 0;
}

else {
    select();
    

}
function select (){
    include ("conn.php");
    
    $query ="SELECT  IdProduct ,p.name As product_name, Description , Image , Price ,Quantity , c.name ,p.IdCategory 
             FROM $table_product p , $table_category c 
             WHERE p.IdCategory = c.IdCategory
             ORDER BY IdProduct";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    
     echo json_encode($data);
    


}


function insert_product(){
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    

    include ("conn.php");
   // selected and uploaded a file
   if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) 
   {
       $name=$_POST['name'];
       $IdCategory=$_POST['IdCategory'];
       $Quantity =$_POST['Quantity'];
       $Price=$_POST['Price'];
       $Description=$_POST['Description'];
   
   
   
             // عملت مصفوفه تحسب الاخطاء
         $errors = array ();
         // جلب معلومات من الفورم
         $image = $_FILES['image'];
         $image_name =$_FILES['image']['name'];
         $image_type =$_FILES['image']['type'];
         $image_temp =$_FILES['image']['tmp_name'];
         $image_error =$_FILES['image']['error'];
         $image_size =$_FILES['image']['size'];
     
   
     
     //  مصفوفه تحتوى على امتدادات الملفات القابلة للرفع
     $allowed_extensions = array ('jpg','gif','jpeg', 'png');
     
     $image_extension = strtolower(end(explode ('.',$image_name)));
         // أعطاء الصورة أسم مستعار
         $image_random = 'IMG-'.$IdCategory.date('Ymd').'-PRO'.rand(0,10000).'.'. $image_extension;
       
     // الشرط الرئيسي تحقق هل في صورة ارتفعت او لا
         if ($image_error == 4 ):
             $errors []= '<div>لم يتم اختيار صورة </div>';
         else:
             // الشرط الاول اذا الصورة حجمها كبير
         if ($image_size > 80000):
             $errors []= '<div>حجم الملف كبير جدأ</div>';
         endif;
     
         //  الشرط الثاني اذا كان امتداد الملف غير مسموح بة
         if  (! in_array($image_extension ,$allowed_extensions)):
         $errors []= '<div>غير مسموح بهذ الامتداد</div>';
         endif;
         if  ( empty($name)):
         $errors []= '<div> يرجي أختيار اسم المنتج </div>';
         endif;
         if  ( empty($IdCategory)):
           $errors []= '<div> يرجي أختيار  الفئه </div>';
         endif;
         if  ( empty($Price)):
         $errors []= '<div> يرجي أدخال سعر المنتج   </div>';
         endif;
         if  ( empty($Quantity)):
         $errors []= '<div> يرجي   تحديد الكمية </div>';
         endif;
         if  ( empty($Description)):
         $errors []= '<div> يرجي    كتابه وصف المنتج </div>';
         endif;
         
         // رفع الصورة في حاله اذا كانت مصفوفه الاخطاء فارغه
         if(empty($errors)):
      
     
   
         // Create the query and insert
                // into our database.
                $query="INSERT INTO $table_product
                (name ,IdCategory,Description,Quantity,Price,Image)
                VALUES('$name','$IdCategory','$Description','$Quantity',$Price,'$image_random') ";
       
                   $results=mysqli_query($connect ,$query);
                  if( $results ){
                      move_uploaded_file ($image_temp ,$_SERVER['DOCUMENT_ROOT'].'\Selvium\img\imgbox\\' . $image_random);
                   echo '<div class="c-green">  تم أضافه المنتج بنجاح   وتم رفع الصورة بنجاح </div>';
              
                   // move_uploaded_file (الموقع الجديد , الموقع القديم , )
   
             
               
               
            
                   }
                   else{
                     print "  لم يتم اضافه المنتج يوجد خطاء  ";
                   }
             
             // في حاله الخطاء سيتم عمل لوب لطباعه الاخطاء
         else:
             foreach($errors as $err):
                 echo '<span class="c-red">' .$err . '</span>';
             endforeach;
         endif; 
     
     endif;
     
     
     }
     
     else {
     
     print "<span class='c-red'> يرجى اختيار صورة  </span>";
     
     }
     
     
     // Close our MySQL Link
   
    //  mysqli_close($connect);
       
   }
   
}



function update_product(){
 
        include ("conn.php");
        $name=$_POST['name'];
        $IdCategory=$_POST['IdCategory'];
        $Quantity =$_POST['Quantity'];
        $Price=$_POST['Price'];
        $Description=$_POST['Description'];
        $IdProduct=$_POST['IdProduct'];
        $image_old=$_POST['image_old'];
       
        // عملت مصفوفه تحسب الاخطاء
        $errors = array ();
        if  ( empty($name)):
            $errors []= '<div> يرجي أختيار اسم المنتج </div>';
        endif;
        if  ( empty($IdCategory)):
              $errors []= '<div> يرجي أختيار  الفئه </div>';
        endif;
        if  ( empty($Price)):
        $errors []= '<div> يرجي أدخال سعر المنتج   </div>';
        endif;
        if  ( empty($Quantity)):
        $errors []= '<div> يرجي   تحديد الكمية </div>';
        endif;
        if  ( empty($Description)):
        $errors []= '<div> يرجي    كتابه وصف المنتج </div>';
        endif;
       // selected and uploaded a file
       if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) 
       {
             // جلب معلومات من الفورم
             $image = $_FILES['image'];
             $image_name =$_FILES['image']['name'];
             $image_type =$_FILES['image']['type'];
             $image_temp =$_FILES['image']['tmp_name'];
             $image_error =$_FILES['image']['error'];
             $image_size =$_FILES['image']['size'];
            $allowed_extensions = array ('jpg','gif','jpeg', 'png');

            
         
            $image_extension = strtolower(end(explode ('.',$image_name)));
             // أعطاء الصورة أسم مستعار
             $image_random =  'IMG-'.$IdCategory.date('Ymd').'-PRO'.rand(0,10000).'.'.$image_extension;
           
            // الشرط الرئيسي تحقق هل في صورة ارتفعت او لا
             if ($image_error == 4 ):
                 $errors []= '<div>لم يتم اختيار صورة </div>';
             else:
                 // الشرط الاول اذا الصورة حجمها كبير
             if ($image_size > 80000):
                 $errors []= '<div>حجم الملف كبير جدأ</div>';
             endif;
         
             //  الشرط الثاني اذا كان امتداد الملف غير مسموح بة
             if  (! in_array($image_extension ,$allowed_extensions)):
             $errors []= '<div>غير مسموح بهذ الامتداد</div>';
             endif;

             
             // رفع الصورة في حاله اذا كانت مصفوفه الاخطاء فارغه
             if(empty($errors)):
             
                    $query="UPDATE  $table_product
                    SET
                    name='".$name."',
                    IdCategory ='".$IdCategory."',
                    Description='".$Description."' ,
                    Quantity ='".$Quantity."',
                    Price = '".$Price."',
                    Image = '".$image_random."'
                    WHERE IdProduct=".$IdProduct;
                 
           
                       $results=mysqli_query($connect ,$query);
                      if( $results ){
                       echo '<div class="c-green">  تم تعديل  المنتج بنجاح   </div>';
                       deleteImage($_SERVER['DOCUMENT_ROOT'].'\Selvium\img\imgbox\\'.$image_old);
                       move_uploaded_file ($image_temp ,$_SERVER['DOCUMENT_ROOT'].'\Selvium\img\imgbox\\'. $image_random);
               
                       }
                       else{
                         print "  لم يتم التعديل  المنتج يوجد خطاء  ";
                       }
                 
                 // في حاله الخطاء سيتم عمل لوب لطباعه الاخطاء
             else:
                 foreach($errors as $err):
                     echo '<span class="c-red">' .$err . '</span>';
                 endforeach;
             endif; 
         
         endif;
         
         
         }
         
       


    if (!isset($_FILES['image'])) {
         
        if(empty($errors)):
             
            $query="UPDATE  $table_product
            SET
            name='".$name."',
            IdCategory ='".$IdCategory."',
            Description='".$Description."' ,
            Quantity ='".$Quantity."',
            Price = '".$Price."'
            WHERE IdProduct=".$IdProduct;
            $results=mysqli_query($connect ,$query);
         
   
               $results=mysqli_query($connect ,$query);
              if( $results ){
                echo '<div class="c-green">  تم تعديل  المنتج بنجاح   </div>';

       
               }
               else{
                 print "  لم يتم التعديل  المنتج يوجد خطاء  ";
               }
         
         // في حاله الخطاء سيتم عمل لوب لطباعه الاخطاء
     else:
         foreach($errors as $err):
             echo '<span class="c-red">' .$err . '</span>';
         endforeach;
     endif; 


     }
         
         

       
         mysqli_close($connect);
           
       
}

function deleteImage($path) {
    // تحقق إذا كان الملف موجود
    if (file_exists($path)) {
        // استخدم دالة unlink لحذف الملف
        if (unlink($path)) {
            echo "تم حذف الصورة بنجاح.";
        } else {
            echo "حدث خطأ أثناء حذف الصورة.";
        }
    } else {
        echo "الصورة غير موجودة.";
    }
}

function delete_product(){

    include "conn.php";
  
    $image_old=$_POST['image_old'];
    $id =    $_POST['IdProduct'] ;
    $query="DELETE  FROM $table_product  WHERE IdProduct =".$id;
       $results=mysqli_query($connect ,$query);
      if( $results ){

        print " تم حذف   " .'<b class="c-main" >  المنتج   </b>'.' بنجاح  ';
        deleteImage($_SERVER['DOCUMENT_ROOT'].'\Selvium\img\imgbox\\'.$image_old);
       }
       else{
         print "لم يتم الحذف";

       }

    // استخدم الدالة

}






