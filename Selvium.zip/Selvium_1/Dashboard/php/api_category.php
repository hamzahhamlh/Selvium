<?php
       if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                return   select();
       }
     
?>
<?php 
    if (  $_POST['stats'] == 'select'   ){
      
        
          return   select();
    }
    
    else if ($_POST['stats'] == 'insert' )
    {
     
        return    insert(); 
    }
    else if ($_POST['stats'] == 'delete' )
    {
       
        return  delete();
    }
    else if ($_POST['stats'] == 'update' ){
       
        return  update ();
    }
    else {
      
         return   select();
            
    }    

function select(){
    include ("conn.php");
    $query ="SELECT IdCategory,name FROM $table_category";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($data);
  
    }
function insert(){
    include "conn.php";

    if (isset( $_POST['name'])  && !empty($_POST['name'])) {
    $name = clear($_POST['name']);
    $query="INSERT INTO $table_category (name)   VALUES ('$name')  ";
       $results=mysqli_query($connect ,$query);
      if( $results ){
        print " تم أضافه  القسم " .'<b class="c-main" >'.  $name . '</b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الاضافه";
       }
    }else{
    print '<b class="c-red">يرجي أدخال اسم !</b>' ;
    }
}
function update(){
    include "conn.php";

    if (isset ( $_POST['name'] ) && $_POST['IdCategory'] ){
        $name =    clear ($_POST['name'] );
        $IdCategory = clear($_POST['IdCategory']);
        $query ="UPDATE $table_category SET Name ='".$name."' WHERE IdCategory =".$IdCategory;

        $results=mysqli_query($connect ,$query);
       if( $results ){
 
         print " تم تعديل القسم الى  ".'<b class="c-main" >'.  $name . '</b>'.' بنجاح  ';
        }
        else{
          print "لم يتم التعديل";
        }
    }
    else{
        print '<b class="c-red">يرجي أدخال اسم !</b>' ;
    }
 }
function delete(){
    include "conn.php";
    $id =    $_POST['ID'] ;
    $query="DELETE  FROM $table_category  WHERE IdCategory =".$id;
       $results=mysqli_query($connect ,$query);
      if( $results ){

        print " تم حذف   " .'<b class="c-main" >  القسم   </b>'.' بنجاح  ';
       }
       else{
         print "لم يتم الحذف";

       }

}







