<?php
header("Access-Control-Allow-Origin: *"); 

function select(){
    include ("conn.php");


    // $query ="SELECT
    //  d.IdDetail As IdDetail ,
    //  d.IdOrder  As IdOrder_detail,
    //  d.IdProduct,
    //  p.IdProduct As IdProduct_product,
    //  p.Name As Name_product,
    //  p.Price AS Price_product,
    //  d.Amount,
    //  d.Price As  Price, 
    //  o.IdOrder As IdOrder_order ,
    //  o.dateOrder As dateOrder,
    //  o.AddressOrder As AddressOrder,
    //  o.Payment As Payment,
    //  o.TotalPrice As TotalPrice,
    //  c.IdCustomer AS IdCustomer,
    //  c.Name As  Name_customer ,
    //  s.IdStateOrder,
    //  s.Name AS Name_stateorder,
    //  s.IdStateOrder As IdStateOrder
    // FROM $table_detail d ,
    //     `$table_order` o ,
    //      $table_customer c,
    //      $table_stateorder s, 
    //      $table_product p
    // WHERE d.IdOrder = o.IdOrder 
    // AND c.IdCustomer = o.IdCustomer
    // AND s.IdStateOrder = o.IdStateOrder
    // AND p.IdProduct = d.IdProduct";
    $query ="SELECT * from  orders";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

    echo json_encode($data);

    // header("Content-Type: JSON");
    mysqli_close($connect);
}






function select_order(){
    include ("conn.php");
   
    $query ="SELECT
         o.IdOrder As IdOrder_order ,
         o.AddressOrder As AddressOrder,
         o.dateOrder As dateOrder,
         o.Payment As Payment,
         o.TotalPrice As TotalPrice,
         c.IdCustomer AS IdCustomer,
         c.Name As  Name_customer ,
         s.IdStateOrder As IdStateOrder,
         s.Name AS Name_stateorder
        FROM `$table_order` o ,
             $table_customer c,
             $table_stateorder s
        WHERE c.IdCustomer = o.IdCustomer
        AND s.IdStateOrder = o.IdStateOrder";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($data);
    // header("Content-Type: JSON");
    mysqli_close($connect);
}



function get_total ()
{
    include ("conn.php");
  
    $query ="SELECT
    d.IdDetail As IdDetail ,
     p.Price*d.Amount  As Price_p
    FROM $table_detail d ,
      `$table_order` o ,
       $table_customer c,
       $table_stateorder s, 
       $table_product p
     WHERE d.IdOrder = o.IdOrder 
    AND c.IdCustomer = o.IdCustomer
    AND s.IdStateOrder = o.IdStateOrder
    AND p.IdProduct = d.IdProduct
    order BY IdDetail";
    $result = mysqli_query($connect,$query);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    $i=0;
    while ($i  < count ( $data )  ){
        $IdDetail = $data[$i]['IdDetail'];
        $Price_p =  $data[$i]['Price_p'];
        // echo  $IdDetail ;
        // echo '<br>';
        // echo $Price_p ;
        $query_updeate ="UPDATE $table_detail d
        SET    d.Price =$Price_p
        WHERE d.IdDetail =".$IdDetail;
        $result = mysqli_query($connect,$query_updeate);
        $i++;
        }
        mysqli_close($connect);
}
function SET_TOTAL_Pris_0(){
    include ("conn.php");
    $query_order="SELECT o.IdOrder 
    FROM `$table_order` o
    WHERE NOT EXISTS (SELECT  d.IdOrder As  IdOrder  FROM $table_detail d WHERE o.IdOrder = d.IdOrder )";
    $result = mysqli_query($connect,$query_order);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode ($data);

    $i=0;
    while ($i  < count ( $data )  ){
    $IdOrder = $data[$i]['IdOrder'] ; 
  

    $query_updeate ="UPDATE `$table_order` o
     SET    o.TotalPrice = 0
    WHERE o.IdOrder =".$IdOrder;

    $result = mysqli_query($connect,$query_updeate);
    $i++;
    }
    mysqli_close($connect);
    return 0 ;
}

function SumPrice(){
    include ("conn.php");
    $query_order ="SELECT
    IdOrder, sum(Price) AS sum_Price
    FROM $table_detail d 
    GROUP By  IdOrder";
    $result = mysqli_query($connect,$query_order);
    $data =mysqli_fetch_all($result,MYSQLI_ASSOC);

    $i=0;
    // echo count ( $data ) ;
    while ($i  < count ( $data )  ){
    $IdOrder = $data[$i]['IdOrder'] ;
    $sum_Price =  $data[$i]['sum_Price'] ;

    $query_updeate ="UPDATE `$table_order` o
    SET    o.TotalPrice=$sum_Price
    WHERE o.IdOrder =".$IdOrder;
    $result = mysqli_query($connect,$query_updeate);
    $i++;
    }
  
   



}


    
    

    function update(){
        include "conn.php";
    
        if (isset ( $_POST['IdStateOrder'] ) && $_POST['IdOrder'] ){
            $IdStateOrder =    clear ($_POST['IdStateOrder'] );
            $IdOrder = clear($_POST['IdOrder']);
            $query ="UPDATE `$table_order` SET IdStateOrder ='".$IdStateOrder."' WHERE IdOrder =".$IdOrder;
    
            $results=mysqli_query($connect ,$query);
           if( $results ){
     
             print " تم تعديل   ".'<b class="c-main" >حاله  الطلب</b>'.' بنجاح  ';
            }
            else{
              print "لم يتم التعديل";
            }
        }
        else{
            print '<b class="c-red">يرجي  تحديد حاله !</b>' ;
        }
     }
    
if ($_POST ['stats'] == 'select' )
{  
    select();
    return 0 ;
}
else if ($_POST['stats'] == 'select_order' )
{
    select_order();
    return 0 ;
}
else if ($_POST['stats'] == 'get_total' )
{
    get_total();
    return 0 ;
}
else if ($_POST['stats'] == 'SumPrice' ){
    SumPrice ();
    return 0;
}
else if ($_POST['stats'] == 'SET_TOTAL_Pris_0' ){
    
    SET_TOTAL_Pris_0();
    return 0;
}
else if ($_POST['stats'] == 'get_total' ){
    get_total ();
    return 0;
}
else if ($_POST['stats'] == 'update' ){
    update ();
    return 0;
}

else {
    select();
    return 0 ;
}

?>

