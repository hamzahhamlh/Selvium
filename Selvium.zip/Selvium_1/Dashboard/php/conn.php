<?php session_start(); 
if ( isset ($_SESSION ['name'] )  ) 
{
//   header("Access-Control-Allow-Origin: *"); 
  $host="localhost";
  $user="id21299170_nwrtalsyry";
  $password="@Nj,pFtLAs5Y8&3r";
  $dbname="id21299170_databeas";
  $connect =mysqli_connect($host,$user,$password,$dbname);
  $table_category = 'category';
  $table_product  = 'product';
  $table_customer = 'customer';
  $table_detail= 'detail';
  $table_order = 'order';
  $table_stateorder = 'stateorder';
  $table_admin = 'admin';
  function clear($input){
      $input = trim($input);
      $input = htmlspecialchars($input,ENT_QUOTES,'UTF-8');
      $input = strip_tags($input);
      return $input;
    }


  }
 