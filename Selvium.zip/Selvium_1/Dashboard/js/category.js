
var datePro;

let table = new  DataTable('.table' ,{

    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;
function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            table.destroy();
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';
            caption.innerHTML = `كل الاقسام ( ${countMyJSObject} )`  ;
           

            // datePro.push(myJSObject);

            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(datePro[i]);
                let ID =  myJSObject[i].IdCategory;
                let name = myJSObject[i].name;
                datePro.push(myJSObject[i]);
                    
            
                 myText+= `<tr>
                    <td>${i+1}</td>
                    <td>${name}</td>
                    <td ><button title="تعديل قسم  ${name}" class="c-green"  onclick="upDate_Category(${i+1})" >تعديل  <i class="fa-solid fa-pen-to-square f-w"></i></button></td>
                    <td><button title="حذف قسم  ${name}" class="c-red"  name="ID" onclick="delete_Category(${ID}) " >حذف  <i class="fa-regular fa-trash-can delete f-w"></i></button></td>
            </tr>`;
       
            }   
          
            let tbody = document.getElementById("tbody");
            tbody.innerHTML = myText ; 
           
           table = new  DataTable('.table' ,
            {
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                }
           }) ;
        }   
    
    };

    myRequest.open('GET', './php/api_category.php', true);
    
    myRequest.send();
}

getRepos();


var btn = document.getElementById('btn') ;

function insert_category() {
    var name= document.getElementById('name').value;
    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(name)    

        if (this.readyState === 4 && this.status === 200) {
           
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
        }
    
    };

    myRequest.open('POST', "./php/api_category.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert&name=" + name);
}


// function upDate_Category(id =1,name =""){}
function upDate_Category( i ){
    var name= document.getElementById('name');
    var IdCategory = document.getElementById ("IdCategory") ;
    btn_save.style.display="inline";
    btn.style.display = "none";
    name.value=datePro[i].name;
    IdCategory.value = datePro[i].IdCategory ;
    name.focus();
    new_name = name.value ;
    IdCategory = datePro[i].IdCategory;
    // console.log (name.value );
    // console.log ( IdCategory );
    
}

var btn_save = document.getElementById('btnsave') ;

btn_save.style.display="none";
btn_save.onclick =set_update ;
function clear_input(){
    var IdCategory = document.getElementById ("IdCategory") ;
    var name= document.getElementById('name');
    IdCategory.value='';
    name.value='';
}

function set_update(){
    var name= document.getElementById('name').value;
    var IdCategory= document.getElementById('IdCategory').value;
    // console.log(name);
    // console.log(IdCategory);

    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');
    myRequest.onreadystatechange = function () {
        

        console.log(name)

        if (this.readyState === 4 && this.status === 200) {
         
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
            btn_save.style.display="none";
            btn.style.display = "inline";
        }
    
    };

    myRequest.open('POST', "./php/api_category.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=update&name="+name+"&IdCategory="+IdCategory);
}



function delete_Category (ID){
    var check_delete = prompt ("هل ترغب فعلا بحذف القسم سوف يتم حذف جميع المنتجات المرتبطه بهذا القسم",check_delete);
    if(check_delete == null){
        return false ;
    }
    // alert("تم حذف القسم مع كل المنتجات" + check_delete ); 
    var myRequest = new XMLHttpRequest();

    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(ID)

        if (this.readyState === 4 && this.status === 200) {
           
            getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            
        }
    
    };

    myRequest.open('POST', "./php/api_category.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=delete&ID="+  ID);
}

