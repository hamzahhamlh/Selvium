
var datePro;

let table = new  DataTable('.table' ,{

    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;
function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            table.destroy();
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';
            caption.innerHTML = `كل الحالات ( ${countMyJSObject} )`  ;
           

            // datePro.push(myJSObject);

            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(datePro[i]);
                let ID =  myJSObject[i].IdStateOrder;
                let name = myJSObject[i].name;
                datePro.push(myJSObject[i]);
                    
            
                 myText+= `<tr>
                    <td>${i+1}</td>
                    <td>${name}</td>
                    <td ><button title="تعديل حاله  ${name}" class="c-green"  onclick="upDate_stateorder(${i+1})" >تعديل  <i class="fa-solid fa-pen-to-square f-w"></i></button></td>
                    <td><button title="حذف حاله  ${name}" class="c-red"  name="ID" onclick="delete_stateorder(${ID}) " >حذف  <i class="fa-regular fa-trash-can delete f-w"></i></button></td>
            </tr>`;
       
            }   
          
            let tbody = document.getElementById("tbody");
            tbody.innerHTML = myText ; 
           
           table = new  DataTable('.table' ,
            {
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                }
           }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_stateorder.php', true);

    myRequest.send("stats=select");
}

getRepos();


var btn = document.getElementById('btn') ;

function insert_stateorder() {
    var name= document.getElementById('name').value;
    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(name)

        if (this.readyState === 4 && this.status === 200) {
           
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
        }
    
    };

    myRequest.open('POST', "./php/api_stateorder.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert&name=" + name);
}


// function upDate_Category(id =1,name =""){}
function upDate_stateorder( i ){
    var name= document.getElementById('name');
    var IdStateOrder = document.getElementById ("IdStateOrder") ;
    btn_save.style.display="inline";
    btn.style.display = "none";
    name.value=datePro[i].name;
    IdStateOrder.value = datePro[i].IdStateOrder ;
    name.focus();
    new_name = name.value ;
    IdStateOrder = datePro[i].IdStateOrder;
    // console.log (name.value );
    // console.log ( IdStateOrder );
    
}

var btn_save = document.getElementById('btnsave') ;

btn_save.style.display="none";
btn_save.onclick =set_update ;
function clear_input(){
    var IdStateOrder = document.getElementById ("IdStateOrder") ;
    var name= document.getElementById('name');
    IdStateOrder.value='';
    name.value='';
}

function set_update(){
    var name= document.getElementById('name').value;
    var IdStateOrder= document.getElementById('IdStateOrder').value;
    // console.log(name);
    // console.log(IdStateOrder);

    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');
    myRequest.onreadystatechange = function () {
        

       

        if (this.readyState === 4 && this.status === 200) {
         
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
            btn_save.style.display="none";
            btn.style.display = "inline";
        }
    
    };

    myRequest.open('POST', "./php/api_stateorder.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=update&name="+name+"&IdStateOrder="+IdStateOrder);
}



function delete_stateorder (ID){
    var check_delete = prompt ("هل ترغب فعلا بحذف الحالة سوف يتم حذف جميع الطلبات المرتبطه بهذا الحالة",check_delete);
    if(check_delete == null){
        return false ;
    }
    // alert("تم حذف القسم مع كل المنتجات" + check_delete ); 
    var myRequest = new XMLHttpRequest();

    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(ID)

        if (this.readyState === 4 && this.status === 200) {
           
            getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            
        }
    
    };

    myRequest.open('POST', "./php/api_stateorder.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=delete&ID="+  ID);
}

