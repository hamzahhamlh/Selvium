const SAR = new Intl.NumberFormat('AR-US', {
    style: 'currency',
    currency: 'SAR',
  });
var datePro;
let table = new  DataTable('.table_order' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;
function formatDate(date) {
    let day = date.getDate();
    let month = date.getMonth() + 1; // يبدأ العد من 0
    let year = date.getFullYear();
    let hours = date.getHours();
    let minutes = date.getMinutes();
  
    // إضافة الصفر قبل الأرقام الأحادية
    if (day < 10) day = '0' + day;
    if (month < 10) month = '0' + month;
    if (hours < 10) hours = '0' + hours;
    if (minutes < 10) minutes = '0' + minutes;
  
    return year + '-' + month + '-' + day ;
  }
  

function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            table.destroy();
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';
         
            SET_TOTAL_Pris_0 ();
            get_total();
            SumPrice();
            // datePro.push(myJSObject);
            let  sum = 0;
            let temp =0  ; 
            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(datePro[i]);
                
                datePro.push(myJSObject[i]);
                // let IdOrder_detail=  datePro[i+1].IdOrder_detail;
                let IdOrder_order=  datePro[i+1].IdOrder_order;
                let IdCustomer=  datePro[i+1].IdCustomer;
                let Name_customer = datePro[i+1].Name_customer;

                let IdStateOrder = datePro[i+1].IdStateOrder;
                let Name_stateorder = datePro[i+1].Name_stateorder;

                let dateOrder = datePro[i+1].dateOrder;
                let AddressOrder = datePro[i+1].AddressOrder;
    
                  
                  let date = new Date(dateOrder);
                //   console.log(formatDate(date)); 
                  // يطبع التاريخ بالتنسيق DD.MM.YYYY
           
                let Amount = datePro[i+1].Amount;
                let Price = datePro[i+1].Price;

                let Payment = datePro[i+1].Payment;
                let TotalPrice = datePro[i+1].TotalPrice;
                temp +=parseInt( TotalPrice) ;
                 myText+= `<tr>
                        <td>${i+1}</td>
          

                    <td>${IdOrder_order}</td>
                    <td>${Name_customer}</td>
                    
      
                    <td>${Name_stateorder}</td>

                    <td>${formatDate(date)}</td>
                    <td>${AddressOrder}</td>

                    <td>${Payment}</td>
                    <td>${SAR.format (TotalPrice )}</td>


                 
                    <td ><a href="#table_Detail"><button  title="عرض تفاصيل الطلب ${IdOrder_order}" class="c-bule"  onclick="getDetail(${IdOrder_order})" > عرض    <i class="far fa-clipboard fa-fw f-w"></i></button></a></td>
                    <td ><button title=" تعديل الطلب ${IdOrder_order}" class="c-green"  onclick="upDate_order(${i+1})" >  تعديل الطلب  <i class="fa-solid fa-pen-to-square f-w"></i></button></td>
            </tr>`;
        }   
        sum = temp ;
            temp = 0;
            caption.innerHTML = `كل الطلبات ( ${countMyJSObject} )  اجمالي قيمه كل طلبات العملاء <b class="c-green f-15"> ${SAR.format (sum) } </b>`  ;
            let tbody = document.getElementById("tbody");
            tbody.innerHTML = myText ; 
           
           table = new  DataTable('.table_order' ,
            {   
                dom: 'Qlfrtip',
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                }
           }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_order.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select_order");
}
getRepos();



var date_order ;
var table_Detail = new  DataTable('.table_Detail' ,{
    // dom: 'Bfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    },
    // order: [[5, 'asc']],
    // rowGroup: {
    // dataSrc: 5
    // }
}) ;



function getDetail(ID) {    
    let myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption_Detail =document.getElementById("caption_Detail");
        let count = 0 ;
        if (this.readyState === 4 && this.status === 200) {
            let myJSObject = JSON.parse(this.responseText);
            date_order=[];
            table_Detail.destroy();
            date_order.push(myJSObject) ;
            let countMyJSObject = myJSObject.length;
            let myDetail = '';
            
            
            // date_order.push(myJSObject);
            let  sum = 0;
            let temp =0  ; 
            for (var i = 0; i < countMyJSObject; i++) {
                
                
                
                // console.log(date_order[i]);
                
                date_order.push(myJSObject[i]);
                
                let IdDetail=  date_order[i+1].IdDetail;
                let IdOrder_order=  date_order[i+1].IdOrder_order;
                
                let IdProduct_product=  date_order[i+1].IdProduct_product;
                let Name_product = date_order[i+1].Name_product;
                let Price_product = date_order[i+1].Price_product;
                
                
                let Amount = date_order[i+1].Amount;
                let Price = date_order[i+1].Price;
                
                temp =   (Amount * Price_product) ;
                
                let Name_stateorder = date_order[i+1].Name_stateorder;
                if (ID == IdOrder_order ) {
                    count++ ;
                    sum +=temp ;
                    myDetail+= `<tr>
                    <td>${i+1}</td>
                    
                    <td>${IdDetail}</td>
                    <td>${IdOrder_order}</td>
                    
                    <td>${IdProduct_product}</td>
                    <td>${Name_product}</td>
                    <td>${SAR.format (Price_product)}</td>
                    

                    <td>${Amount}</td>
                    <td>${SAR.format (Price)}</td>
                    
                    </tr>`;
                }
            }   
         
                temp = 0 ;
            caption_Detail.innerHTML = `<b>عدد التفاصيل =  ${count} </b>     <i>  للطلب رقم     ( ${ID} )  </i> اجمالي القيمه <b class="c-green f-15"> ${SAR.format (sum) } </b>`  ;
            let tbody_Detail = document.getElementById("tbody_Detail");
            tbody_Detail.innerHTML = myDetail ; 
           
            table_Detail = new  DataTable('.table_Detail' ,
            {   
                // dom: 'Bfrtip',
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                },
                // order: [[5, 'asc']],
                // rowGroup: {
                // dataSrc: 5
                // }
           }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_order.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select");
}
// getDetail();





function get_total (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            // console.log ( this.responseText);    
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=get_total");
}
function SET_TOTAL_Pris_0 (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            // console.log ( this.responseText);    
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=SET_TOTAL_Pris_0");
}

function SumPrice (){
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            // console.log ( this.responseText);
        }
    };
    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=SumPrice");
}




var btn_save = document.getElementById('btnsave') ;
let update= document.getElementById('update');

btn_save.style.display="none";

update.style.display="none";
btn_save.onclick =set_update ;

let  inp_IdOrder = document.getElementById ('IdOrder');
function upDate_order( i ){
    var IdStateOrder= document.getElementById('IdStateOrder');
    
    
    // console.log(inp_IdOrder)
//    console.log (IdStateOrder);
   
   inp_IdOrder.value = datePro[i].IdOrder_order  ;
   IdStateOrder.value = datePro[i].IdStateOrder  ;
//    console.log(datePro[i].IdOrder_order )
//    console.log(datePro[i].IdStateOrder )
   let update= document.getElementById('update');
    btn_save.style.display="inline";
    update.style.display = "flex";
    IdStateOrder.focus () ; 
 
    
}

function set_update(){
    var IdStateOrder= document.getElementById('IdStateOrder').value;
    var IdOrder= document.getElementById('IdOrder').value;
    // console.log(IdOrder);
    // console.log(IdStateOrder);

    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');
    let update= document.getElementById('update');
    myRequest.onreadystatechange = function () {
        

        // console.log(IdStateOrder)

        if (this.readyState === 4 && this.status === 200) {
         
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            // clear_input();
            btn_save.style.display="none";
            // update.style.display = "none";
        }
    
    };

    myRequest.open('POST', "./php/api_order.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=update&IdStateOrder="+IdStateOrder+"&IdOrder="+IdOrder);
}



function select_StateOrder() {
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            var countMyJSObject = myJSObject.length;
            let myText = '';
            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(myJSObject[i]);
                let ID = myJSObject[i].IdStateOrder;
                let name = myJSObject[i].name;
                myText += `<option value="${ID}" >${name} </option>`;
            }
            let select = document.getElementById("IdStateOrder");
            select.innerHTML += myText;
        }
    };
    myRequest.open('POST', './php/api_stateorder.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select");
}
select_StateOrder();