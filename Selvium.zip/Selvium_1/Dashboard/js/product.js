var datePro;
let table = new  DataTable('.table' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    },
  
}) ;
function getRepos() {
    var myRequest = new XMLHttpRequest();

    myRequest.onreadystatechange = function () {
      
        let caption =document.getElementById("caption");
      
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            datePro.push(myJSObject) ;
     
            var countMyJSObject = myJSObject.length;
            let myText = '';

            table.destroy();

            for (var i = 0; i < countMyJSObject; i++) {
                datePro.push(myJSObject[i]);
                // console.log(myJSObject[i]);
                let ID =  myJSObject[i].IdProduct;
                
                let name = datePro[i+1].product_name;
                let Category_name = datePro[i+1].name;
                let Price = datePro[i+1].Price;
                let Quantity = datePro[i+1].Quantity ; 
                let Image = datePro[i+1].Image ; 
                let Description = datePro[i+1].Description ; 
                // console.log(datePro[i])
                caption.innerHTML = `كل المنتجات ( ${countMyJSObject} )`  ;

                 myText+= `<tr>
                    <td>${i+1}</td>
                    <td>${name}</td>
                    <td>${Description}</td>
                    <td>${Category_name}</td>
                    <td><img src="../img/imgbox/${Image}"></td>
                    <td>${Price}</td>
                    <td>${Quantity}</td>
                    <td><button title="تعديل ${name}" class="c-green"  onclick="update_product(${i+1})" >تعديل  <i class="fa-solid fa-pen-to-square f-w"></i></button></td>
                    <td><button title="حذف   ${name}" class="c-red"    onclick="delete_product(${ID},${i+1}) " >حذف  <i class="fa-regular fa-trash-can delete f-w"></i></button></td>
            </tr>`;

            }   
            caption.innerHTML = `كل المنتجات ( ${countMyJSObject} )`  ;   
            let tbody = document.getElementById("tbody");
            tbody.innerHTML = myText ; 
            table = new  DataTable('.table' ,{
                dom: 'Qlfrtip',
            language:{
                url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
            },
     
            footerCallback: function (row, data, start, end, display) {
                var api = this.api();
                // حساب مجموع التجزئة لكل مجموعة من الصفوف المجمعة
                var total = api.column(3, {page: 'current'}).data().reduce(function (a, b) {
                    return a + b;
                }, 0);
                // تحديث قيمة الإجمالي في صف الإجمالي
                $(api.column(4).footer()).html(total);
            }
           }) ;
        }

    
    };
  

    myRequest.open('GET', './php/api_product.php', true);

    myRequest.send();
}
getRepos();


let imgbox =document.querySelector("#box-img");
let img =document.getElementById('img');
let uplode =document.getElementById('uplode');

// console.log(img);
// console.log(imgbox);
// console.log(uplode);





uplode.onchange =function(){
//   console.log(uplode.files[0]);
  imgbox.style.display ="block";

  imgbox.style.transform= "scale(1)";
  let file =new FileReader();
  file.readAsDataURL(uplode.files[0]);
  file.onload =function (){
    img.src = file.result;
  }
}


function select_category() {
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            var countMyJSObject = myJSObject.length;
            let myText = '';
            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(myJSObject[i]);
                let ID = myJSObject[i].IdCategory;
                let name = myJSObject[i].name;
                myText += `<option value="${ID}" >${name} </option>`;
            }
            let select = document.getElementById("IdCategory");
            select.innerHTML += myText;
        }
    };
    myRequest.open('GET', './php/api_category.php', true);
    myRequest.send();
}
select_category();

function insert_product(){
    let IdCategory = document.getElementById ('IdCategory').value;
    let name  = document.getElementById ('name').value ;
    let Quantity  = document.getElementById ('Quantity').value ;
    let Price  = document.getElementById ('Price').value ;
    let Description  = document.getElementById ('Description').value ;
    let uplode  = document.getElementById ('uplode') ;

 

    var formData = new FormData();

    formData.append('stats', 'insert');
    formData.append('name', name);
    formData.append('IdCategory', IdCategory);
    formData.append('Quantity', Quantity);
    formData.append('Description', Description);
    formData.append('Price', Price);
    formData.append('image', uplode.files[0]);

   
    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            masg.innerHTML = this.responseText;
            if (this.responseText == `<div class="c-green">  تم أضافه المنتج بنجاح   وتم رفع الصورة بنجاح </div>`)

            {
                btnupdate.style.display = "none";
                btnseve.style.display ="inline";
                getRepos();
                clear_input();

            }
        }
    
    };

    myRequest.open('POST', "./php/api_product.php", true);
    myRequest.send(formData);
}

var btnupdate  = document.getElementById ('btnupdate');
var btnseve  = document.getElementById ('btnseve');

function update_product(i){
    masg.innerHTML = '';
    show_form()
    let IdProduct = document.getElementById ('IdProduct');
    let IdCategory = document.getElementById ('IdCategory');
    let name  = document.getElementById ('name') ;
    let Quantity  = document.getElementById ('Quantity') ;
    let Price  = document.getElementById ('Price') ;
    let Description  = document.getElementById ('Description');
    let img  = document.getElementById ('img');
    let image_old  = document.getElementById ('image_old');



    btnupdate.style.display = "inline";
    btnseve.style.display ="none";


    IdCategory.value = datePro[i].IdCategory;
    IdProduct.value = datePro[i].IdProduct;
    name.value = datePro[i].product_name;
    Quantity.value = datePro[i].Quantity;
    Price.value = datePro[i].Price;
    Description.value = datePro[i].Description;
    img.src ='../img/imgbox/' +datePro[i].Image;
    image_old.value = datePro[i].Image;
    IdCategory.focus()
    btnupdate.onclick = setupdate
    

}

function setupdate(){
    let IdProduct = document.getElementById ('IdProduct').value;
     let IdCategory = document.getElementById ('IdCategory').value;
    let name  = document.getElementById ('name').value ;
    let Quantity  = document.getElementById ('Quantity').value ;
    let Price  = document.getElementById ('Price').value ;
    let Description  = document.getElementById ('Description').value ;
    let uplode  = document.getElementById ('uplode') ;
    let image_old  = document.getElementById ('image_old').value;
  
    var formData = new FormData();

    formData.append('stats', 'update');
    formData.append('IdProduct', IdProduct);
    formData.append('image_old', image_old);
    formData.append('name', name);
    formData.append('IdCategory', IdCategory);
    formData.append('Quantity', Quantity);
    formData.append('Description', Description);
    formData.append('Price', Price);
    formData.append('image', uplode.files[0]);

   
    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText;
           
        
            if (this.responseText == `<div class="c-green">  تم تعديل  المنتج بنجاح   </div>`
              || this.responseText == `<div class="c-green">  تم تعديل  المنتج بنجاح   </div>تم حذف الصورة بنجاح.`)

            {
                btnupdate.style.display = "none";
                btnseve.style.display ="inline";
                getRepos();
                clear_input();
                close_form();

            }
        }
    
    };

    myRequest.open('POST', "./php/api_product.php", true);
    myRequest.send(formData);
}


function clear_input(){
    document.getElementById ('IdProduct').value='';
    document.getElementById ('IdCategory').value='';
    document.getElementById ('name').value='' ;
    document.getElementById ('Quantity').value='' ;
    document.getElementById ('Price').value='' ;
    document.getElementById ('Description').value='' ;
    document.getElementById ('uplode').value='' ;
    document.getElementById ('image_old').value='' ;
    document.getElementById ('img').src='' ;
}





function delete_product (IdProduct,i){

    var check_delete = prompt ("هل ترغب فعلا بحذف المنتج سوف يتم حذف جميع البيانات والطلبات المرتبطه بهذا المنتج",check_delete);
    if(check_delete == null){
        return false ;
    }

   
    
    var formData = new FormData();

    formData.append('stats', 'delete'); 
    formData.append('IdProduct', IdProduct);
    formData.append('image_old',datePro[i].Image);
    var myRequest = new XMLHttpRequest();
    
    let masg= document.getElementById('masg');
    
    myRequest.onreadystatechange = function () {
        
        
        // console.log(IdProduct)
        // console.log(image_old.value)

        
        if (this.readyState === 4 && this.status === 200) {
            
            
            getRepos() ;
            clear_input();
            close_form()

            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            
        }
    
    };
    myRequest.open('POST', "./php/api_product.php", true);
    myRequest.send(formData);
}
