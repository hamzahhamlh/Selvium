var datePro;

let table = new  DataTable('.table' ,{
    dom: 'Qlfrtip',
    language:{
        url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
    }
}) ;
function getRepos() {    
    var myRequest = new XMLHttpRequest();
    myRequest.onreadystatechange = function () {
      let caption =document.getElementById("caption");

        if (this.readyState === 4 && this.status === 200) {
            var myJSObject = JSON.parse(this.responseText);
            datePro=[];
            table.destroy();
            datePro.push(myJSObject) ;
            var countMyJSObject = myJSObject.length;
            let myText = '';
            caption.innerHTML = `كل العملاء ( ${countMyJSObject} )`  ;
           

            // datePro.push(myJSObject);

            for (var i = 0; i < countMyJSObject; i++) {
                // console.log(datePro[i]);
               
                datePro.push(myJSObject[i]);
                let ID=  datePro[i+1].IdCustomer;
                let name = datePro[i+1].Name;
                let Password = datePro[i+1].Password;
                let tump_pass = '*'.repeat(Password.length)
                let Email = datePro[i+1].Email;
                let Mobile = datePro[i+1].Mobile;
                let Age = datePro[i+1].Age;
                let Address = datePro[i+1].Address;
            
                 myText+= `<tr>
                    <td>${i+1}</td>
                    <td>${name}</td>
                    <td>${tump_pass}</td>
                    <td>${Email}</td>
                    <td>${Mobile}</td>
                    <td>${Age}</td>
                    <td>${Address}</td>
                    <td ><button title="تعديل عميل  ${name}" class="c-green"  onclick="upDate_Customer(${i+1})" >تعديل  <i class="fa-solid fa-pen-to-square f-w"></i></button></td>
                    <td><button title="حذف عميل  ${name}" class="c-red"  name="ID" onclick="delete_Customer(${ID}) " >حذف  <i class="fa-regular fa-trash-can delete f-w"></i></button></td>
            </tr>`;
       
            }   
          
            let tbody = document.getElementById("tbody");
            tbody.innerHTML = myText ; 
           
           table = new  DataTable('.table' ,
            {   
                dom: 'Qlfrtip',
                language:{
                    url: '../DataTables/plug-ins/1.13.6/i18n/ar.json'
                }
           }) ;
        }   
    
    };

    myRequest.open('POST', './php/api_customer.php', true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=select");
}

getRepos();



function insert_customer (){
    var Name= document.getElementById('Name').value;
    var Password= document.getElementById('Password').value;
    var Email= document.getElementById('Email').value;
    var Mobile= document.getElementById('Mobile').value;
    var Age= document.getElementById('Age').value;
    var Address= document.getElementById('Address').value;

    // console.log(Name);
    // console.log(Password);
    // console.log(Email);
    // console.log(Mobile);
    // console.log(Age);
    // console.log(Address);
    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(Name)

        if (this.readyState === 4 && this.status === 200) {
            
             
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            if ( this.responseText == " تم أضافه العميل بنجاح  " ){

                getRepos() ;
                close_form() ; 
                clear_input(); 
            }
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=insert&Name="+Name+"&Password="+Password+"&Email="+Email+"&Mobile="+Mobile+"&Age="+Age+"&Address="+Address);

}


function upDate_Customer( i ){
    show_form()
    var IdCustomer= document.getElementById('IdCustomer');
    var Name= document.getElementById('Name');
    var Password= document.getElementById('Password');
    var Email= document.getElementById('Email');
    var Mobile= document.getElementById('Mobile');
    var Age= document.getElementById('Age');
    var Address= document.getElementById('Address');
   
    btn_save.style.display="inline";
    btn.style.display = "none";

    IdCustomer.value=datePro[i].IdCustomer;
    Name.value=datePro[i].Name;
    Password.value=datePro[i].Password;
    Email.value=datePro[i].Email;
    Mobile.value=datePro[i].Mobile;
    Age.value=datePro[i].Age;
    Address.value=datePro[i].Address;

    // IdCustomer.value = datePro[i].IdCustomer ;
    Name.focus();
   
    // IdCustomer = datePro[i].IdCustomer;
    // console.log (Name.value );
    // console.log ( IdCustomer );
    
}

var btn_save = document.getElementById('btnsave') ;

btn_save.style.display="none";
btn_save.onclick =set_update ;


function set_update(){

    var IdCustomer= document.getElementById('IdCustomer').value;
    var Name= document.getElementById('Name').value;
    var Password= document.getElementById('Password').value;
    var Email= document.getElementById('Email').value;
    var Mobile= document.getElementById('Mobile').value;
    var Age= document.getElementById('Age').value;
    var Address= document.getElementById('Address').value;

    // console.log(IdCustomer);
    // console.log(Name);
    // console.log(Password);
    // console.log(Email);
    // console.log(Mobile);
    // console.log(Age);
    // console.log(Address);

    var myRequest = new XMLHttpRequest();
    let masg= document.getElementById('masg');
    myRequest.onreadystatechange = function () {
        

        // console.log(Name)
        // console.log(IdCustomer)

        if (this.readyState === 4 && this.status === 200) {
         
            new getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            clear_input();
            btn_save.style.display="none";
            btn.style.display = "inline";
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=update&IdCustomer="+IdCustomer+"&Name="+Name+"&Password="+Password+"&Email="+Email+"&Mobile="+Mobile+"&Age="+Age+"&Address="+Address);
}



function clear_input (){
    let Name= document.getElementById('Name');
    let Password= document.getElementById('Password');
    let Email= document.getElementById('Email');
    let Mobile= document.getElementById('Mobile');
    let Age= document.getElementById('Age');
    let Address= document.getElementById('Address');
     Name.value = " ";
     Password.value = "";
     Email.value ='';
     Mobile.value ='';
     Age.value ='';
     Address.value ='';
}



function delete_Customer (ID){
    var check_delete = prompt ("هل ترغب فعلا بحذف هذا العميل سوف يتم حذف جميع البيانات المرتبطه به",check_delete);
    if(check_delete == null){
        return false ;
    }

    var myRequest = new XMLHttpRequest();

    let masg= document.getElementById('masg');

    myRequest.onreadystatechange = function () {
        

        // console.log(ID)

        if (this.readyState === 4 && this.status === 200) {
           
            getRepos() ;
            // console.log ( this.responseText);
            masg.innerHTML = this.responseText ;
            
        }
    
    };

    myRequest.open('POST', "./php/api_customer.php", true);
    myRequest.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    myRequest.send("stats=delete&ID="+ID);
}
