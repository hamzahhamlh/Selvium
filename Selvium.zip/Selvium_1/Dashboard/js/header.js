document.body.innerHTML +=`    <div class="scroller"></div>

<button type="button" id="btn-scrool" src="...">
    <i class="fa-solid fa-angles-up mr-10"></i>
</button>`;
let header = document.getElementById ("header");




//------------------scroller------------
window.onscroll =scroller ;
function scroller(){
    let btn_scrool=document.getElementById('btn-scrool');
    btn_scrool.title = "انقر للذهاب  الى اعلى الصفحه ";
window.onscroll=function()
{
    if( scrollY >= 400)
    {
        btn_scrool.style.display='block';
    }
    else
    {
        btn_scrool.style.display='none';        
    }
}
btn_scrool.onclick=function(){window.scrollTo({
    left:0,
    top:0,
    behavior:"smooth"
})
}

    let el=document.querySelector('.scroller');
    let height=document.documentElement.scrollHeight-document.documentElement.clientHeight;
    
    console.log(document.documentElement.scrollHeight);
    console.log(document.documentElement.clientHeight);
    console.log(height);
    
    window.addEventListener('scroll',()=>{
        let scrollTop =document.documentElement.scrollTop;
        // console.log(scrollTop);
        el.style.width=`${(scrollTop/height)*100}%`; 
    });
    
}



function get() {    
    var xhrhttp = new XMLHttpRequest();
    xhrhttp.onreadystatechange = function () {

        // console.log(this.status)
        // console.log (this.responseText)

        if (this.readyState === 4 && this.status === 200) {
            let header = document.getElementById ("header");
            let user = this.responseText ;      
            header.innerHTML +=` <div class="container">
            <a href="index.html" class="logo">سلفيوم</a>
            <ul class="main-nav">
                <li><a href="index.html">الرئيسيه</a>  </li>
                <li><a href="#gallery"> المنتجات</a>
                    <div class="mega-menu">
            
                        <ul class="links">
                            <li>
                                <a href="category.html"><i class="fa-solid fa-list  fa-rotate-180 fa-fw"></i>أدارة الاقسام</a>
                            </li>
                            <li>
                                <a href="product.html"><i class="fa-solid  fa-shop   fa-fw"></i>أدارة المنتجات </a>
                            </li>
                            <li>
                                <a href="order.html"><i class=" far fa-clipboard fa-fw"></i>أدارة الطلبات </a>
                            </li>
                            <li>
                                <a href="stateorder.html"><i class="far fa-building fa-fw"></i>أدارة حالات الطلب</a>
                            </li>
                        
                        </ul>
            
                    </div>
                </li>
                <li>
                    <a href="#"> المستخدمين</a>
                    <!-- Start Megamenu -->
                    <div class="mega-menu">
            
                        <ul class="links">
                            <li>
                                <a href="customer.html"><i class="fa-solid fa-users fa-fw"></i>أداره العملاء</a>
                            </li>
                            <li>
                                <a href="admin.html"><i class="far fa-user fa-fw"></i>أدارة المستخدمين </a>
                            </li>
                          
                        </ul>
            
                    </div>
                    <!-- End Megamenu -->
                </li>
                <li><a href="Reports.html"> التقاير </a> </li>
                <li><a href="./php/Session_unset.php">تسجيل الخروج</a>
          
                </li>
            
            </ul>
            <div  class="user">
                <a href="#"><i class="far fa-user fa-fw"></i>  ${user} </a>
            </div>
            </div>
            `;

            var myJSObject =this.responseText ;
            // console.log (myJSObject)
            // console.log (this.responseText) 

            
        }   
    
    };

    xhrhttp.open('GET', './php/Session_user.php', true);
    xhrhttp.send();
}

get ();

function locat(){

    console.log("location.href      = " + location.href);
    console.log("location.protocol  = " + location.protocol);
    console.log("location.hostname  = " + location.hostname);
    console.log("location.pathname  = " + location.pathname);
   }
   locat()