<?php session_start();

// تدمير متغيرات الجلسة المحددة

unset($_SESSION['client']);
unset($_SESSION['client_name']);
unset($_SESSION['client_Email']);
unset($_SESSION['client_id']);
unset($_SESSION['client_Address']);
?>
<!DOCTYPE html>
<html lang="AR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>  تسجيل الدخول - عميل</title>
    <link rel="icon" href="../img/icon_title.ico" type="image/x-icon" />
    <!-- link file css -->
    <link rel="stylesheet" href="./style.css">
</head>


<body>
    <div class="contanier">
        <div class="login">
            <img class="user" src="./img/user.jpg" alt="">
  
            <h1>مرحبا بك</h1>
            <form action="../Client/php/Session.php" method="POST">

                <label for="">البريد الالكتروني</label>
                <input type="email" name="username"  value="<?php echo $_GET['username']?>" placeholder="أدخل عنوان بريدك الالكتروني" required>

                <label for="">كلمة المرور</label>
                <input type="password" name="Password" placeholder="ادخل كلمة المرور" required>
               
                <button  >دخول</button>
            </form>

            <div class="bottom-div">
                <div class="line-or">
                    <span>أو</span>
                </div>

                <div class="btns">
                    <a href="#" class="btn"><img class="fb" src="./img/facebook.png" alt=""></a>
                    <a href="#" class="btn"><img class="google" src="./img/google.png" alt="" ></a>
                </div>
                <p  class="signup">ليس لديك حساب ؟<a href="../Client/customer.html"> أنشاء حساب  </a></p>

               
            
   
                <p class="signup">  او <a href="index.html"> تسجيل الدخول كمدير  </a></p>

            </div>
        </div>
    </div>


</body>
</html>